# 涅槃基础框架dubbo服务的maven项目模板
专用于生成涅槃项目的业务层和数据层的微服务maven项目

## 技术框架选型

* dubbo-sf.2.0.4
* spring3.2.8
* zookeeper3.4.6

## 使用方法

模板已经发布到http://10.118.46.12:8081/nexus/content/groups/public/中

````
	<groupId>com.sf.sgs</groupId>
	<artifactId>sgs-template</artifactId>
	<version>2.1.4</version>
````



