/*
 * Copyright (c) 2017, 2018, sf-express and/or its affiliates. All rights reserved.
 * sf-express PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sf.exception;

import com.sf.framework.domain.Result;
import com.sf.constants.ServiceReturnCode;
import com.sf.i18n.CommonMessageSource;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 833902 2018年2月9日 下午4:25:23
 */
@Provider
public class GlobalExceptionHandler implements ExceptionMapper<Exception> {

  private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

  @Override
  public Response toResponse(Exception e) {
    LOGGER.error("", e);
    Result<Object> result = new Result<>();
    result.setSuccess(false);
    int errorCode = ServiceReturnCode.GLOBAL_ERROR;
    String message = CommonMessageSource.getAccessor().getMessage(String.valueOf(errorCode));
    if (e instanceof BusinessException) {
      errorCode = ((BusinessException) e).getCode();
      message = e.getMessage();
    }

    result.setErrorCode(String.valueOf(errorCode));
    result.setErrorMessage(message);
    return Response.ok(result, MediaType.APPLICATION_JSON_TYPE).build();
  }


}
