/*
 * Copyright (c) 2017, 2018, sf-express and/or its affiliates. All rights reserved.
 * sf-express PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sf.constants;

/**
 * @author 833902 2018年3月2日 下午3:24:39
 */
public interface ServiceReturnCode {


  /**
   * 全局异常
   */
  int GLOBAL_ERROR = 500;

}
