###微服务模板使用规范
1.client----接口定义层
2.

注意点：
1）属性管理：模板一种是disconf管理、一种是spring容器管理，标准请使用disconf管理，如果需要spring容器管理请看spring-config。service.xml的配置说明