package com.sf.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sf.framework.domain.Result;
import com.sf.framework.utils.ConvertDomainUtils;
import com.sf.framework.validate.ParamValidate;
import com.sf.manager.DemoUserManager;
import com.sf.model.DemoUser;
import com.sf.model.DemoUserExample;
import com.sf.model.extend.DemoUserExtend;
import com.sf.provider.service.DemoUserService;
import com.sf.service.DemoUserRestService;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * DemoUserrestful服务实现类
 *
 * @author 698533
 */
@Service
public class DemoUserRestServiceImpl implements DemoUserRestService {

  private Logger logger = LoggerFactory.getLogger(getClass());

  @Autowired
  DemoUserManager demoUserManager;

  @Autowired
  @Qualifier("providerUserService")
  private DemoUserService providerUserService;

  //@Value("#{configProperties['system.name']}")
  //@Value("#{'system.name'}")
  private String sysName;

  /**
   * 按主键删除
   *
   * @return Result<Integer>
   */
  public Result<Integer> deleteByPrimaryKey(Integer id) {
    Result<Integer> result = new Result<Integer>(true);
    if (id == null) {
      throw new IllegalStateException("参数id不能为空");
    }
    int count = demoUserManager.deleteByPrimaryKey(id);
    result.setObj(Integer.valueOf(count));
    return result;
  }

  /**
   * 新增
   *
   * @param record 记录
   * @return Result<Integer>
   */
  @ParamValidate
  public Result<Integer> insert(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.insert(record);
    result.setObj(Integer.valueOf(count));
    return result;
  }

  /**
   * 按条件查询
   *
   * @param example 条件
   * @param pageNum 页码
   * @param pageSize 每页数量
   * @return Page
   */
  public Result<PageInfo<DemoUser>> selectByExample(DemoUserExample example, Integer pageNum,
      Integer pageSize) {
    Result<PageInfo<DemoUser>> result = new Result<PageInfo<DemoUser>>(true);
    if (pageNum != null && pageNum < 1) {
      throw new IllegalStateException("参数pageNum不能小于1");
    }
    if (pageSize != null && pageSize < 1) {
      throw new IllegalStateException("参数pageSize不能小于1");
    }
    if ((pageNum == null && pageSize != null)
        || (pageNum != null && pageSize == null)) {
      throw new IllegalStateException("pageNum、pageSize必须同时为null或不为null");
    }
    if (pageNum == null && pageSize == null) {//一次查所有数据
      pageNum = 1;
      pageSize = 0;
    }
    PageHelper.startPage(pageNum, pageSize);
    Page<DemoUser> records = (Page<DemoUser>) demoUserManager.selectByExample(example);
    result.setObj(records.toPageInfo());
    return result;
  }

  /**
   * 按主键查询
   *
   * @return List
   */
  public Result<DemoUser> selectByPrimaryKey(Integer id) throws Exception {

    Result<com.sf.provider.model.DemoUser> userResp = providerUserService.selectByPrimaryKey(id);

    Result<DemoUser> result = new Result<>();
    BeanUtils.copyProperties(userResp, result);
    return result;

//    if (id < 1) {
//      throw new BusinessException(10010);
//    }
//
//    Result<DemoUser> result = new Result<DemoUser>(true);
//    if (id == null) {
//      throw new IllegalStateException("参数id不能为空");
//    }
//    DemoUser record = demoUserManager.selectByPrimaryKey(id);
//    result.setObj(record);
//    return result;
  }

  /**
   * 按主键更新,null的字段不更新
   *
   * @param record 记录
   * @return List
   */
  public Result<Integer> updateByPrimaryKeySelective(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.updateByPrimaryKeySelective(record);
    result.setObj(Integer.valueOf(count));
    return result;
  }

  /**
   * 按主键更新
   *
   * @param record 记录
   * @return Result<Integer>
   */
  public Result<Integer> updateByPrimaryKey(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.updateByPrimaryKey(record);
    result.setObj(Integer.valueOf(count));
    return result;
  }

  /**
   * 自己新增代码
   */
  @Override
  public Result<List<DemoUser>> selectAll() {
    Result<List<DemoUser>> result = new Result<List<DemoUser>>(true);

    List<DemoUserExtend> list = demoUserManager.selectAll();
    if (CollectionUtils.isNotEmpty(list)) {
      List<DemoUser> rList = ConvertDomainUtils.convertList(list, DemoUser.class);
      result.setObj(rList);
    } else {
      result.setSuccess(false);
      //自己按照业务逻辑定义一套错误码以及描述
      result.setErrorCode("001");
      result.setErrorMessage("-------");
    }

    return result;
  }

}