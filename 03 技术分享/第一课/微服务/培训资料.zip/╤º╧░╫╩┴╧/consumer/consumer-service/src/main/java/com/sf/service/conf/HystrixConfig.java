package com.sf.service.conf;

import com.baidu.disconf.client.common.annotations.DisconfFile;
import com.baidu.disconf.client.common.annotations.DisconfUpdateService;
import com.baidu.disconf.client.common.update.IDisconfUpdate;
import com.netflix.config.ConfigurationManager;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
@DisconfFile(filename = HystrixConfig.HYSTRIX_CONFIG_NAME)
@DisconfUpdateService(classes = {HystrixConfig.class})
public class HystrixConfig implements InitializingBean, IDisconfUpdate {

  public static final String HYSTRIX_CONFIG_NAME = "hystrix.properties";
  private static final Logger log = LoggerFactory.getLogger(HystrixConfig.class);

  @Override
  public void afterPropertiesSet() throws Exception {
    loadProperties();
  }

  @Override
  public void reload() throws Exception {
    loadProperties();
  }

  private void loadProperties() {
    try {
      ConfigurationManager.getConfigInstance().clear();
      ConfigurationManager.loadPropertiesFromResources(HYSTRIX_CONFIG_NAME);
    } catch (IOException e) {
      log.error("加载hystrix.properties配置发错", e);
    }
  }
}