package com.sf.service.kafka;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class KafkaConf {

  // kafka生产者配置start
  @Value(value = "${kafaka.product.poolsize}")
  private int poolSize;

  @Value(value = "${kafaka.product.clustername}")
  private String proClusterName;

  @Value(value = "${kafaka.product.systemurl}")
  private String proSystemUrl;

  @Value(value = "${kafaka.product.template.topicTokens}")
  private String templateTopicToken;

  @Value(value = "${kafaka.product.template.topic}")
  private String templateTopic;

  // kafka生产者配置end
  @Value(value = "${kafaka.consume_messageGroupSize}")
  private int messageGroupSize;

  @Value(value = "${kafaka.consume_consumeThreadCount}")
  private int consumeThreadCount;

  @Value(value = "${kafaka.consume_clusterName}")
  private String conClusterName;

  @Value(value = "${kafaka.consume_systemIdToken}")
  private String systemIdToken;

  @Value(value = "${kafaka.consume_systemUrl}")
  private String conSystemUrl;

  @Value(value = "${kafaka.consume_topic_sgs_resource}")
  private String consume_topic_sgs_resource;

  public int getPoolSize() {
    return poolSize;
  }

  public void setPoolSize(int poolSize) {
    this.poolSize = poolSize;
  }

  public String getProClusterName() {
    return proClusterName;
  }

  public void setProClusterName(String proClusterName) {
    this.proClusterName = proClusterName;
  }

  public String getProSystemUrl() {
    return proSystemUrl;
  }

  public void setProSystemUrl(String proSystemUrl) {
    this.proSystemUrl = proSystemUrl;
  }

  public String getTemplateTopicToken() {
    return templateTopicToken;
  }

  public void setTemplateTopicToken(String templateTopicToken) {
    this.templateTopicToken = templateTopicToken;
  }

  public String getTemplateTopic() {
    return templateTopic;
  }

  public void setTemplateTopic(String templateTopic) {
    this.templateTopic = templateTopic;
  }

  public int getMessageGroupSize() {
    return messageGroupSize;
  }

  public void setMessageGroupSize(int messageGroupSize) {
    this.messageGroupSize = messageGroupSize;
  }

  public int getConsumeThreadCount() {
    return consumeThreadCount;
  }

  public void setConsumeThreadCount(int consumeThreadCount) {
    this.consumeThreadCount = consumeThreadCount;
  }

  public String getConClusterName() {
    return conClusterName;
  }

  public void setConClusterName(String conClusterName) {
    this.conClusterName = conClusterName;
  }

  public String getSystemIdToken() {
    return systemIdToken;
  }

  public void setSystemIdToken(String systemIdToken) {
    this.systemIdToken = systemIdToken;
  }

  public String getConSystemUrl() {
    return conSystemUrl;
  }

  public void setConSystemUrl(String conSystemUrl) {
    this.conSystemUrl = conSystemUrl;
  }

  public String getConsume_topic_sgs_resource() {
    return consume_topic_sgs_resource;
  }

  public void setConsume_topic_sgs_resource(String consume_topic_sgs_resource) {
    this.consume_topic_sgs_resource = consume_topic_sgs_resource;
  }

}

