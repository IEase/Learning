package com.sf.provider.mapper;

import com.sf.provider.model.DemoUser;
import com.sf.provider.model.DemoUserExample;
import com.sf.provider.model.extend.DemoUserExtend;
import java.util.List;

/**
 * @author 698533
 */
public interface DemoUserMapper {

  int deleteByPrimaryKey(Integer id);

  int insert(DemoUser record);

  int insertSelective(DemoUser record);

  List<DemoUser> selectByExample(DemoUserExample example);

  DemoUser selectByPrimaryKey(Integer id);

  int updateByPrimaryKeySelective(DemoUser record);

  int updateByPrimaryKey(DemoUser record);

  /**
   * 自定义方法，查询关联信息
   */
  List<DemoUserExtend> selectAll();
}