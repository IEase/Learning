package com.sf.provider.service.impl;

import com.alibaba.dubbo.rpc.RpcException;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sf.framework.domain.Result;
import com.sf.framework.validate.ParamValidate;
import com.sf.provider.manager.DemoUserManager;
import com.sf.provider.model.DemoUser;
import com.sf.provider.model.DemoUserExample;
import com.sf.provider.service.DemoUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * DemoUserService实现类
 *
 * @author 698533
 */
@Service
public class DemoUserServiceImpl implements DemoUserService {

  @Autowired
  DemoUserManager demoUserManager;
  private Logger logger = LoggerFactory.getLogger(getClass());

  /**
   * 按主键删除
   *
   * @return Result<Integer>
   */
  public Result<Integer> deleteByPrimaryKey(Integer id) {
    Result<Integer> result = new Result<Integer>(true);
    if (id == null) {
      throw new IllegalStateException("参数id不能为空");
    }
    int count = demoUserManager.deleteByPrimaryKey(id);
    result.setObj(Integer.valueOf(count));

    return result;
  }

  /**
   * 新增
   *
   * @param record 记录
   * @return Result<Integer>
   */
  @ParamValidate
  public Result<Integer> insert(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.insert(record);
    result.setObj(Integer.valueOf(count));
    return result;
  }

  /**
   * 按条件查询
   *
   * @param example 条件
   * @param pageNum 页码
   * @param pageSize 每页数量
   * @return Page
   */
  public Result<PageInfo<DemoUser>> selectByExample(DemoUserExample example, Integer pageNum,
      Integer pageSize) {
    Result<PageInfo<DemoUser>> result = new Result<PageInfo<DemoUser>>(true);
    if (pageNum != null && pageNum < 1) {
      throw new IllegalStateException("参数pageNum不能小于1");
    }
    if (pageSize != null && pageSize < 1) {
      throw new IllegalStateException("参数pageSize不能小于1");
    }
    if ((pageNum == null && pageSize != null)
        || (pageNum != null && pageSize == null)) {
      throw new IllegalStateException("pageNum、pageSize必须同时为null或不为null");
    }
    if (pageNum == null && pageSize == null) { //一次查所有数据
      pageNum = 1;
      pageSize = 0;
    }
    PageHelper.startPage(pageNum, pageSize);
    Page<DemoUser> records = (Page<DemoUser>) demoUserManager.selectByExample(example);
    result.setObj(records.toPageInfo());
    return result;
  }

  /**
   * 按主键查询
   *
   * @return List
   */
  public Result<DemoUser> selectByPrimaryKey(Integer id) {
    Result<DemoUser> result = new Result<DemoUser>(true);
    if (id == null) {
      throw new IllegalStateException("参数id不能为空");
    }
    DemoUser record = demoUserManager.selectByPrimaryKey(id);
    result.setObj(record);

    return result;
  }

  /**
   * 按主键更新,null的字段不更新
   *
   * @param record 记录
   * @return List
   */
  public Result<Integer> updateByPrimaryKeySelective(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.updateByPrimaryKeySelective(record);
    result.setObj(Integer.valueOf(count));

    return result;
  }

  /**
   * 按主键更新
   *
   * @param record 记录
   * @return Result<Integer>
   */
  public Result<Integer> updateByPrimaryKey(DemoUser record) {
    Result<Integer> result = new Result<Integer>(true);
    if (record == null) {
      throw new IllegalStateException("参数record不能为空");
    }
    if (record.getId() == null) {
      throw new IllegalStateException("主键id属性不能为空");
    }
    int count = demoUserManager.updateByPrimaryKey(record);
    result.setObj(Integer.valueOf(count));
    return result;
  }

}