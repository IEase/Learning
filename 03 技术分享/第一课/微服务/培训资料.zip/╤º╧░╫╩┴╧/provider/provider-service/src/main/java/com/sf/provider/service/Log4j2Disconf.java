package com.sf.provider.service;

import com.baidu.disconf.client.common.annotations.DisconfFile;
import com.baidu.disconf.client.common.annotations.DisconfUpdateService;
import com.baidu.disconf.client.common.update.IDisconfUpdate;
import java.net.URISyntaxException;
import java.net.URL;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 自动加载log4j2.xml配置（由于新部署项目还没有从disconf配置中心下载到log4j2.xml配置）
 *
 * 在disconf统一配置中心后台改动会自动重新加载最新配置
 *
 * @author YANGLiiN 2017-09-05 13:41
 */

@Component
@DisconfFile(filename = Log4j2Disconf.LOG4J2_CONFIG_NAME)
@DisconfUpdateService(classes = {Log4j2Disconf.class})
public class Log4j2Disconf implements InitializingBean,
    IDisconfUpdate {

  public static final String LOG4J2_CONFIG_NAME = "log4j2.xml";

  @Override
  public void afterPropertiesSet() throws Exception {
    loadProperties();
  }

  @Override
  public void reload() throws Exception {
    loadProperties();
  }

  private void loadProperties() {
    URL url = Log4j2Disconf.class.getResource("/" + LOG4J2_CONFIG_NAME);
    LoggerContext context = (LoggerContext) LogManager.getContext(false);
    try {
      // this will force a reconfiguration
      context.setConfigLocation(url.toURI());
    } catch (URISyntaxException e) {
      e.printStackTrace();
    }
  }


}
