package com.sf.provider.service;

import com.alibaba.dubbo.container.Main;

public class DemoServerMain {

  public static void main(String[] args) {
    Main.main(args);
  }

}
