package com.sf.provider.test;

import com.sf.framework.domain.Result;
import com.sf.provider.model.DemoUser;
import com.sf.provider.service.DemoUserRestService;
import com.sf.provider.service.DemoUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DemoUserAction {

  private Logger logger = LoggerFactory.getLogger(getClass());

  private DemoUserService demoUserService;

  private DemoUserRestService demoUserRestService;


  public void setDemoUserService(DemoUserService demoUserService) {
    this.demoUserService = demoUserService;
  }


  public void setDemoUserRestService(DemoUserRestService demoUserRestService) {
    this.demoUserRestService = demoUserRestService;
  }


  public void start() throws Exception {
    for (int i = 0; i < Integer.MAX_VALUE; i++) {
      try {
        Result<DemoUser> result = demoUserService.selectByPrimaryKey(1);
        if (result.getObj() != null) {
          System.out.println(result.getObj().getName());
        }

      } catch (Exception e) {
        e.printStackTrace();
      }
      Thread.sleep(2000);
    }
  }

}
