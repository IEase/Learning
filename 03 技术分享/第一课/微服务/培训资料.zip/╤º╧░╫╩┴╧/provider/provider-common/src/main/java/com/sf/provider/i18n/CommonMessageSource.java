package com.sf.provider.i18n;

import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.context.support.ResourceBundleMessageSource;

public class CommonMessageSource extends ResourceBundleMessageSource {

  private static MessageSourceAccessor messages = new MessageSourceAccessor(
      new CommonMessageSource());

  public CommonMessageSource() {
    setBasename("messages/error_code");
  }

  public static MessageSourceAccessor getAccessor() {
    return messages;
  }
}
