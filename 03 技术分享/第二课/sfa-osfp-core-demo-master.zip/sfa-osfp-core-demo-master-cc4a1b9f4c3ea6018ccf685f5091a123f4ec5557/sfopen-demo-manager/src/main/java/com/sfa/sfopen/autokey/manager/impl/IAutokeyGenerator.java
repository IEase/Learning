package com.sfa.sfopen.autokey.manager.impl;


import com.sfa.sfopen.autokey.domain.Autokey;

/**
 * 编号生成器
 * 
 * @author 856418
 *
 */
public interface IAutokeyGenerator {

    int getRule();

    /**
     * 生成新的编号
     * 
     * @param autokey
     * @return
     */
    Autokey generator(Autokey autokey);

    /**
     * 按照当前seed生成编号
     * 
     * @param autokey
     * @return
     */
    Autokey generatorCurno(Autokey autokey);
}
