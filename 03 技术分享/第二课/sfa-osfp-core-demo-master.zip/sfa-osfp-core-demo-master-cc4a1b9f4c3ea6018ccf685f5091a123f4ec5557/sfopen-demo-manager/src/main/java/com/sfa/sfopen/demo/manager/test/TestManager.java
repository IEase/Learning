package com.sfa.sfopen.demo.manager.test;

import java.util.List;

import com.sfa.sfopen.demo.domain.test.OrgDo;

public interface TestManager {

	List<OrgDo> listRegionOrg();
	
	List<OrgDo> listHeadOrg();
	
	List<OrgDo> listTechOrg();
	
	
}
