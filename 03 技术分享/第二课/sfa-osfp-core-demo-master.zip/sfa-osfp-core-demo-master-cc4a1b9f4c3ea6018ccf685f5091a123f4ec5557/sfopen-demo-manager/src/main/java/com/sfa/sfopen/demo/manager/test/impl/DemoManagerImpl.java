/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.manager.test.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.sfopen.demo.domain.test.SysConf;
import com.sfa.sfopen.demo.manager.test.DemoManager;
import com.sfa.sfopen.demo.mapper.test.DemoMapper;

/**
 * @author 01163853
 *
 */
@Service
public class DemoManagerImpl implements DemoManager{
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private DemoMapper sysConfMapper;

    @Override
    public SysConf selectByPrimaryKey(String confKey) {
        return sysConfMapper.selectByPrimaryKey(confKey);
    }

    @Override
    public Integer deleteByPrimaryKey(String confKey) {
        return sysConfMapper.deleteByPrimaryKey(confKey);
    }

    @Override
    public Integer insert(SysConf conf) {
        return sysConfMapper.insert(conf);
    }

    @Override
    public Integer updateByPrimaryKeySelective(SysConf conf) {
        return sysConfMapper.updateByPrimaryKeySelective(conf);
    }

    @Override
    public Integer updateByPrimaryKey(SysConf conf) {
        return sysConfMapper.updateByPrimaryKey(conf);
    }

    @Override
    public List<SysConf> selectByParam(SysConf conf) {
        return sysConfMapper.selectByParam(conf);
    }

}
