/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.autokey.manager.impl;

import com.sfa.sfopen.autokey.domain.Autokey;
import com.sfa.sfopen.autokey.manager.IAutokeyManager;
import com.sfa.sfopen.autokey.mapper.AutokeyMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author 01163853
 *
 */
@Service
public class AutokeyManagerImpl implements IAutokeyManager {
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private AutokeyMapper autokeyMapper;

    @Override
    public Autokey queryAutokey(Map map) {

        return autokeyMapper.queryAutokey(map);
    }

    @Override
    public void updateAutokey(Autokey autokey) {

        autokeyMapper.updateAutokey(autokey);
    }

    @Override
    public void insertAutokey(Autokey autokey) {

        autokeyMapper.insertAutokey(autokey);
    }

    @Override
    public void deleteAutokey(String id) {

        autokeyMapper.deleteAutokey(id);

    }

    @Override
    public Autokey findAutokeyById(String id) {

        return  autokeyMapper.findAutokeyById(id);

    }

}
