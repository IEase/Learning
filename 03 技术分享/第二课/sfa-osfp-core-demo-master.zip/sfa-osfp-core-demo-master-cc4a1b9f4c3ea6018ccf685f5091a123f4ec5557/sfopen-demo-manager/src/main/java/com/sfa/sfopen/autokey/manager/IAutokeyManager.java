/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.autokey.manager;


import com.sfa.sfopen.autokey.domain.Autokey;

import java.util.Map;

/**
 * @author 01163853
 *
 */
public interface IAutokeyManager {


	Autokey queryAutokey(Map map);

	void updateAutokey(Autokey autokey);

	void insertAutokey(Autokey autokey);

	void deleteAutokey(String  id);

	Autokey findAutokeyById(String id);


}
