/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.manager.test;

import java.util.List;
import com.sfa.sfopen.demo.domain.test.SysConf;

/**
 * @author 01163853
 *
 */
public interface DemoManager {

	/**
	 * 
	 * @param confKey
	 * @return
	 */
	SysConf selectByPrimaryKey(String confKey);

	/**
	 * 按条件查询
	 * 
	 * @param sysConf
	 *            条件
	 *
	 */
	List<SysConf> selectByParam(SysConf sysConf);

	/**
	 * 按ID删除
	 * 
	 * @param confKey
	 * @return
	 */
	Integer deleteByPrimaryKey(String confKey);

	/**
	 * 新增
	 * 
	 * @param conf
	 * @return
	 */
	Integer insert(SysConf conf);

	/**
	 * 修改
	 * 
	 * @param conf
	 * @return
	 */
	Integer updateByPrimaryKeySelective(SysConf conf);

	/**
	 * 修改
	 * 
	 * @param conf
	 * @return
	 */
	Integer updateByPrimaryKey(SysConf conf);
}
