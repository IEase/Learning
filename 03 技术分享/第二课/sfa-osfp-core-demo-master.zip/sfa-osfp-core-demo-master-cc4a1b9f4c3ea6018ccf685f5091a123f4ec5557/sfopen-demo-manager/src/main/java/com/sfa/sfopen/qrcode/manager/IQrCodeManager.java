/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.qrcode.manager;


import com.sfa.sfopen.qrcode.domain.QrCode;

/**
 * @author 01374973
 */
public interface IQrCodeManager {

    void insertQrCode(QrCode qrCode);


    QrCode queryQrCodeByEntityId(String entityId);


}
