/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.qrcode.manager.impl;
import com.sfa.sfopen.qrcode.domain.QrCode;
import com.sfa.sfopen.qrcode.manager.IQrCodeManager;
import com.sfa.sfopen.qrcode.mapper.QrCodeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author 01374973
 */
@Service
public class QrCodeManagerImpl implements IQrCodeManager {

    private org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(this.getClass().getName());

    @Autowired
    private QrCodeMapper qrCodeMapper;

    @Override
    public void insertQrCode(QrCode qrCode) {

        qrCodeMapper.insert(qrCode);
    }


    @Override
    public QrCode queryQrCodeByEntityId(String entityId) {

        return qrCodeMapper.queryQrCodeByEntityId(entityId);

    }

}
