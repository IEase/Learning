package com.sfa.sfopen.demo.manager.test.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.sfopen.demo.domain.test.OrgDo;
import com.sfa.sfopen.demo.manager.test.TestManager;
import com.sfa.sfopen.demo.mapper.test.TestMapper;

@Service
public class TestManagerImpl implements TestManager {

	@Autowired
	private TestMapper mapper;

	private final String REGION = "region";

	private final String HEAD = "region";

	private final String TECH = "region";

	@Override
	public List<OrgDo> listRegionOrg() {
		return mapper.listOrg(REGION);
	}

	@Override
	public List<OrgDo> listHeadOrg() {
		return mapper.listOrg(HEAD);
	}

	@Override
	public List<OrgDo> listTechOrg() {
		return mapper.listOrg(TECH);
	}

}
