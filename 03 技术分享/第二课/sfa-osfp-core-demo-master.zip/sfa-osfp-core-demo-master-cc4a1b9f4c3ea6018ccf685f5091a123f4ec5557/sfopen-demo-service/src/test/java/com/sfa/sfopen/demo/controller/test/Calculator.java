package com.sfa.sfopen.demo.controller.test;
public class Calculator {  
      
    private Adder adder;  
  
    public void setAdder(Adder adder) {  
      
        this.adder = adder;  
    }  
      
    public int add(int x, int y){  
        return adder.add(x, y);  
    }  
  
}  