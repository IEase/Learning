package com.sfa.sfopen.demo.controller.test;
import junit.framework.TestCase;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest extends TestCase {

	private Calculator tested;

	private Adder adder;

	@Before
	public void setUp() {

		tested = new Calculator();
		adder = EasyMock.createMock(Adder.class);
		tested.setAdder(adder);
	}

	@Test
	public void testAdd() {
		// adder in record state
		EasyMock.expect(adder.add(1, 2)).andReturn(3);
		EasyMock.replay(adder);
		// adder in replay state
		Assert.assertEquals(3, tested.add(1, 2));
	}
}
