package com.sfa.sfopen.demo.controller.test;
public interface Adder {  
      
    public int add(int x, int y);  
}  