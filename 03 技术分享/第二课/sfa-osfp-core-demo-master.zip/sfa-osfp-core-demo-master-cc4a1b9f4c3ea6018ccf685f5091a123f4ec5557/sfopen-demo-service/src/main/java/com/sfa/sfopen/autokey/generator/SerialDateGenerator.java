/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;

import com.sf.erui.util.DateUtil;
import com.sfa.sfopen.autokey.domain.Autokey;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * 日期+序列格式编号生成器 <br>
 *
 * @author 刘志(667096)
 * @create 2018/8/29
 * @since 1.0.0
 */
@Service public class SerialDateGenerator extends AbstractAutokeyGenerator {

    public SerialDateGenerator() {
        super(Autokey.RULE_DATE);
    }

    /**
     * 按照Autokey定义生成编号
     * @param autokey   编号生成规则
     * @return Autokey对象, 包含生成后的编号
     */
    @Override public Autokey generator(Autokey autokey) {
        String seed = getResetOrIncreaseSeed(autokey);
        String no = generateNo(autokey, seed);
        return resetAutokey(autokey, seed, no);
    }

    /**
     * 根据规则计算下一个SEED
     * @param autokey   编号生成规则
     * @return 下一个SEED
     */
    private String getResetOrIncreaseSeed(Autokey autokey) {
        String format = autokey.getFormat();
        String seed = autokey.getSeed();
        String lastDate = seed.substring(0, format.length());
        String curDate = DateUtil.date2Str(new Date(), format);
        String serial = seed.substring(format.length(), seed.length());
        if (lastDate.compareTo(curDate) >= 0) {
            serial = increaseSeed(serial);
        } else {
            serial = resetSeed(serial);
        }
        return joinString(null, curDate, serial);
    }
}
