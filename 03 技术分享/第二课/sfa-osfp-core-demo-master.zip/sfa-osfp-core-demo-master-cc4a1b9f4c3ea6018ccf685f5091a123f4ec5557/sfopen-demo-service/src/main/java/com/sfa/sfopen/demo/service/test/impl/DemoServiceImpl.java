/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.service.test.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sfa.sfopen.demo.domain.test.SysConf;
import com.sfa.sfopen.demo.manager.test.DemoManager;
import com.sfa.sfopen.demo.service.test.DemoService;

/**
 * @author 01163853
 *
 */
@Service
public class DemoServiceImpl implements DemoService {

    private static final Logger logger = LoggerFactory.getLogger(DemoServiceImpl.class);

    @Autowired
    private DemoManager demoManager;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#selectByPrimaryKey(java.
     * lang.String)
     */
    @Override
    public SysConf selectByPrimaryKey(String confKey) {
        return demoManager.selectByPrimaryKey(confKey);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#selectByParam(com.sfa.
     * sfopen.demo.domain.test.SysConf)
     */
    @Override
    public List<SysConf> selectByParam(SysConf sysConf) {
        return demoManager.selectByParam(sysConf);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#deleteByPrimaryKey(java.
     * lang.String)
     */
    @Override
    public Integer deleteByPrimaryKey(String confKey) {
        return demoManager.deleteByPrimaryKey(confKey);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#insert(com.sfa.sfopen.
     * demo.domain.test.SysConf)
     */
    @Override
    public Integer insert(SysConf conf) {
        return demoManager.insert(conf);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.sfa.sfopen.demo.service.test.SysConfService#
     * updateByPrimaryKeySelective(com.sfa.sfopen.demo.domain.test.SysConf)
     */
    @Override
    public Integer updateByPrimaryKeySelective(SysConf conf) {
        return demoManager.updateByPrimaryKeySelective(conf);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#updateByPrimaryKey(com.
     * sfa.sfopen.demo.domain.test.SysConf)
     */
    @Override
    public Integer updateByPrimaryKey(SysConf conf) {
        return demoManager.updateByPrimaryKey(conf);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.sfa.sfopen.demo.service.test.SysConfService#selectByParamOnPage(com.
     * sfa.sfopen.demo.domain.test.SysConf, java.lang.Integer,
     * java.lang.Integer)
     */
    @Override
    public PageInfo<SysConf> selectByParamOnPage(SysConf sysConf, Integer pageNum, Integer pageSize) {
        PageInfo<SysConf> records = null;
        PageHelper.startPage(pageNum, pageSize);
        try {
            records = new PageInfo<SysConf>(demoManager.selectByParam(sysConf));
        } catch (Exception e) {
            logger.error("selectByExample error", e);
            throw e;
        }
        return records;
    }

}
