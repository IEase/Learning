package com.sfa.sfopen.aop;

import com.sf.erui.mybatis.support.MultipleDataSourceHolder;
import com.sfa.sfopen.annotation.SFDataSource;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Component
public class DataSourceAspect {

    @Before("@annotation(com.sfa.sfopen.annotation.SFDataSource)")
    public void before(JoinPoint point){
        //获得当前访问的class
        Class<?> className = point.getTarget().getClass();
        SFDataSource dataSourceAnnotation = className.getAnnotation(SFDataSource.class);
        if (dataSourceAnnotation != null ) {
            //获得访问的方法名
            String methodName = point.getSignature().getName();
            //得到方法的参数的类型
            Class[] argClass = ((MethodSignature)point.getSignature()).getParameterTypes();
            String dataSource = SFDataSource.DATA_SOURCE_ASMS;
            try {
                Method method = className.getMethod(methodName, argClass);
                if (method.isAnnotationPresent(SFDataSource.class)) {
                    SFDataSource annotation = method.getAnnotation(SFDataSource.class);
                    dataSource = annotation.dataSource();
                    System.out.println("DataSource Aop ====> "+dataSource);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            MultipleDataSourceHolder.setContextType(dataSource);
        }

    }



    @After("@annotation(com.sfa.sfopen.annotation.SFDataSource)")
    public void after(JoinPoint point){
        String dataSource = MultipleDataSourceHolder.getContextType();
        //MultipleDataSourceHolder.setContextType(dataSource);
        if(dataSource != null && !SFDataSource.DATA_SOURCE_ASMS.equals(dataSource)) {
            MultipleDataSourceHolder.clearContextType();
        }
    }
}
