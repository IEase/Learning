/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.service.impl;

import com.sfa.sfopen.autokey.domain.Autokey;
import com.sfa.sfopen.autokey.generator.AutokeyGeneratorFactory;
import com.sfa.sfopen.autokey.generator.IAutokeyGenerator;
import com.sfa.sfopen.autokey.mapper.AutokeyMapper;
import com.sfa.sfopen.autokey.service.IAutokeyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class AutokeyServiceImpl implements IAutokeyService {

    private static final Logger log = LoggerFactory.getLogger(AutokeyServiceImpl.class);

    @Autowired
    private AutokeyMapper autokeyMapper;

    @Override
    public Autokey queryAutokey(String module, String name, String model, String ata) {

        Map<String,String> map =  new HashMap<>();
        map.put("module",module);
        map.put("name",name);
        map.put("model",model);
        map.put("ata",ata);
        return  autokeyMapper.queryAutokey(map);
    }

    @Override
    public String genNo(String module, String name) {
        Map<String,String> map =  new HashMap<>();
        map.put("module",module);
        map.put("name",name);

        Autokey autokey = autokeyMapper.queryAutokey(map);
        return genNo(autokey);
    }

    /**
     * 根据机型获取编号
     */
    @Override
    public String genNoByModel(String module, String name, String model,String ata) {
        Map<String,String> map =  new HashMap<>();
        map.put("module",module);
        map.put("name",name);
        map.put("model",model);
        map.put("ata",ata);

        Autokey autokey =  autokeyMapper.queryAutokey(map);
        return genNo(autokey);
    }

    /**
     * 生成当前seed对应的编号
     */
    @Override
    public Autokey generatorCurno(Autokey autokey) {
        IAutokeyGenerator autokeyGenerator = AutokeyGeneratorFactory.getInstance(Integer.parseInt(autokey.getRule()));
        autokey = autokeyGenerator.generatorCurno(autokey);
        return autokey;
    }

    /**
     *
     * @param autokey
     * @return
     */
    @Override
    public String genNo(Autokey autokey) {
        IAutokeyGenerator autokeyGenerator = AutokeyGeneratorFactory.getInstance(Integer.parseInt(autokey.getRule()));
        autokey = autokeyGenerator.generator(autokey);
        try {
            autokeyMapper.updateAutokey(autokey);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return autokey.getCurNo();
    }


    /**
     * 保存新的编号生成规则
     */
    @Override
    public boolean save(Autokey autokey) {
        if (isExit(autokey)) {
            return false;
        }
        if (autokey != null && autokey.getId() != null) {
            Autokey dbAutokey;
            try {
                dbAutokey = findAutokeyById(autokey.getId());
                dbAutokey = fillAutokey(dbAutokey, autokey);

                autokeyMapper.updateAutokey(dbAutokey);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else {
            autokey.setCtime(new Date());
            try {
                autokeyMapper.insertAutokey(autokey);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return true;
    }

    /**
     * 将从页面传递来的autokey的参数复制给数据库中的dbAutokey
     *
     * @param dbAutokey
     * @param autokey
     * @return
     */
    public Autokey fillAutokey(Autokey dbAutokey, Autokey autokey) {
        dbAutokey.setId(autokey.getId());
        dbAutokey.setModel(autokey.getModel());
        dbAutokey.setModule(autokey.getModule());
        dbAutokey.setName(autokey.getName());
        dbAutokey.setAta(autokey.getAta());
        dbAutokey.setRule(autokey.getRule());
        dbAutokey.setPrefix(autokey.getPrefix());
        dbAutokey.setSuffix(autokey.getSuffix());
        dbAutokey.setSeed(autokey.getSeed());
        dbAutokey.setCurNo(autokey.getCurNo());
        dbAutokey.setMtime(autokey.getMtime());
        dbAutokey.setCtime(autokey.getCtime());
        dbAutokey.setConnector(autokey.getConnector());
        dbAutokey.setDisabled(autokey.getDisabled());
        return dbAutokey;
    }

    /**
     * 判断数据表中是否存在同名的记录
     *
     * @param autokey
     * @return
     */
    protected boolean isExit(Autokey autokey) {
        Autokey dbAutokey = null;
            Map<String,String> map =  new HashMap<>();
            map.put("module",autokey.getModule());
            map.put("name",autokey.getName());
            map.put("model",autokey.getModel());
            map.put("ata",autokey.getAta());

        dbAutokey = autokeyMapper.queryAutokey(map);

        return dbAutokey != null && !dbAutokey.getId().equals(autokey.getId());
    }

    /**
     * 删除某条编号生成规则
     */
    @Override
    public void delete(Autokey autokey) {
        Autokey dbAutokey = findAutokeyById(autokey.getId());
        dbAutokey.setDisabled("1");
        autokeyMapper.updateAutokey(dbAutokey);
    }

    /**
     * 根据id查找记录对象并返回
     * @param id ID
     */
    @Override public Autokey findAutokeyById(String id) {
        return  autokeyMapper.findAutokeyById(id);
    }
}
