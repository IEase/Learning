/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;

import com.sfa.sfopen.autokey.domain.Autokey;

import javax.annotation.PostConstruct;
import java.util.Date;

/**
 * 编号生成器抽象类 <br>
 *
 * @author 刘志(667096)
 * @create 2018/8/29
 * @since 1.0.0
 */
public abstract class AbstractAutokeyGenerator implements IAutokeyGenerator {

    /*编号规则*/
    private int rule;

    public AbstractAutokeyGenerator() {
        super();
    }

    public AbstractAutokeyGenerator(int rule) {
        super();
        this.rule = rule;
    }

    @PostConstruct public void init() {
        AutokeyGeneratorFactory.register(this);
    }

    @Override public Autokey generatorCurno(Autokey autokey) {
        String no = generateNo(autokey, autokey.getSeed());
        return resetAutokey(autokey, autokey.getSeed(), no);
    }

    /**
     * 流水号增加1 ，增加保存“-”
     *  如：0001、-0001、0000-0001变为 0002、-0002、0000-0002
     * @param seed  编号seed
     * @return 新的seed
     */
    protected String increaseSeed(String seed) {
        String  prefix = "";
       if(seed.indexOf("-") >= 0){
           prefix = seed.substring(0,seed.lastIndexOf("-")+1);
           seed = seed.substring(seed.lastIndexOf("-")+1,seed.length());
       }
        int intSeed = Integer.valueOf(seed) + 1;
        return prefix+String.format("%" + '0' + seed.length() + "d", intSeed);
    }

    /**
     * 重置流水号，增加保存“-”
     *
     * @param seed 编号seed
     * @return 新的seed
     */
    protected String resetSeed(String seed) {
        String  prefix = "";
        if(seed.indexOf("-") >= 0){
            prefix = seed.substring(0,seed.lastIndexOf("-")+1);
            seed = seed.substring(seed.lastIndexOf("-")+1,seed.length());
        }
        return prefix+String.format("%" + '0' + seed.length() + "d", 1);
    }

    /**
     * 基于Seed生成完整编号
     *
     * @param autokey   编号定义
     * @param seed  编号的SEED
     * @return 编号
     */
    protected String generateNo(Autokey autokey, String seed) {
        return joinString(autokey.getConnector(), autokey.getPrefix(), seed, autokey.getSuffix());
    }

    /**
     * 链接字符串
     *
     * @param connector 连接符
     * @param strs  需要连接的字符串
     * @return
     */
    protected String joinString(String connector, String... strs) {

        StringBuilder sb = new StringBuilder();
        for (String str : strs) {
            if (str == null || str.isEmpty()) {
                continue;
            }
            if (sb.length() > 0 && connector != null) {
                sb.append(connector);
            }
            sb.append(str);
        }
        return sb.toString();
    }

    /**
     * 重置编号定义
     *
     * @param autokey   编号定义
     * @param seed  Seed
     * @param no    当前编号
     * @return Autokey对象, 包含生成后的编号
     */
    protected Autokey resetAutokey(Autokey autokey, String seed, String no) {
        autokey.setSeed(seed);
        autokey.setCurNo(no);
        autokey.setMtime(new Date());
        return autokey;
    }

    @Override public int getRule() {
        return rule;
    }
}
