/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;


import com.sfa.sfopen.autokey.domain.Autokey;

/**
 * 编号生成器接口
 *
 * @author 刘志(667096)
 * @date 2018/8/29
 * @since 1.0.0
 */
public interface IAutokeyGenerator {

    int getRule();

    /**
     * 生成新的编号
     *
     * @param autokey   编号定义
     * @return Autokey对象, 包含生成后的编号
     */
    Autokey generator(Autokey autokey);

    /**
     * 按当前seed生成编号
     * @param autokey   编号定义
     * @return Autokey对象, 包含生成后的编号
     */
    Autokey generatorCurno(Autokey autokey);
}
