package com.sfa.sfopen.demo.service.test;

import java.util.List;

import com.sfa.sfopen.demo.domain.test.TableMeta;

public interface MultiDsService {

	List<TableMeta> queryTabs(String sql); 

}
