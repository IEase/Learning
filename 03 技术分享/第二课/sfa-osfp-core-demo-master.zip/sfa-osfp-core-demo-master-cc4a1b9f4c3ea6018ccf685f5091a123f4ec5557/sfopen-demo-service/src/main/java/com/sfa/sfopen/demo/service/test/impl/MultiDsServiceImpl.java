package com.sfa.sfopen.demo.service.test.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.sfopen.demo.domain.test.TableMeta;
import com.sfa.sfopen.demo.mapper.test.MultiDsMapper;
import com.sfa.sfopen.demo.service.test.MultiDsService;

@Service
public class MultiDsServiceImpl implements MultiDsService {

	@Autowired
	private MultiDsMapper mapper;
	
	
	@Override
	public List<TableMeta> queryTabs(String sql) {
		
		return mapper.queryTabs(sql);
	}

}
