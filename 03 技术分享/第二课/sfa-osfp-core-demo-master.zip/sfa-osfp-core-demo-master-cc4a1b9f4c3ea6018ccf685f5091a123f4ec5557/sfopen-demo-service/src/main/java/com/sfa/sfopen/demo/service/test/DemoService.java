/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.service.test;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.sfa.sfopen.demo.domain.test.SysConf;

/**
 * SysConf表Service类
 * @author 01163853
 *
 */
public interface DemoService {
    
    /**
     * 
     * @param confKey
     * @return
     */
    SysConf selectByPrimaryKey(String confKey);

    
    /**
     * 按条件查询
     * 
     * @param sysConf 条件
     *
    */
    List<SysConf> selectByParam(SysConf sysConf);
    
    /**
     * 分页查询
     * @param sysConf
     * @param pageNum
     * @param pageSize
     * @return
     */
    PageInfo<SysConf> selectByParamOnPage(SysConf sysConf, Integer pageNum, Integer pageSize);
    
    /**
     * 按ID删除
     * @param confKey
     * @return
     */
    Integer deleteByPrimaryKey(String confKey);
    
    /**
     * 新增
     * @param conf
     * @return
     */
    Integer insert(SysConf conf);
    
    /**
     * 修改
     * @param conf
     * @return
     */
    Integer updateByPrimaryKeySelective(SysConf conf);
    
    /**
     * 修改
     * @param conf
     * @return
     */
    Integer updateByPrimaryKey(SysConf conf);

}
