/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;

import com.sfa.sfopen.autokey.domain.Autokey;

import java.util.Date;

/**
 * 带日期类编号生成器抽象类 <br>
 * 前缀+日期+流水号+后缀组成编号
 *
 * @author 刘志(667096)
 * @create 2018/8/29
 * @since 1.0.0
 */
public abstract class AbstractDateSerialGenerator extends AbstractAutokeyGenerator {

    /*日期格式化方式*/
    private String format;

    public AbstractDateSerialGenerator() {
        super();
    }

    public AbstractDateSerialGenerator(int rule, String format) {
        super(rule);
        this.format = format;
    }

    @Override public Autokey generator(Autokey autokey) {
        String seed = getResetOrIncreaseSeed(autokey);
        String no = generateNo(autokey, seed);
        return resetAutokey(autokey, seed, no);
    }

    private String getResetOrIncreaseSeed(Autokey autokey) {

        String seed = autokey.getSeed();
        String lastDate = seed.substring(0, format.length());
        String curDate = new Date().toString();
        String serial = seed.substring(format.length());
        if (lastDate.compareTo(curDate) >= 0) {
            serial = increaseSeed(serial);
        } else {
            serial = resetSeed(serial);
        }
        return joinString(null, curDate, serial);
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

}
