package com.sfa.sfopen.demo.controller.test;

import java.net.URISyntaxException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sf.erui.common.response.Response;
import com.sf.erui.common.response.ResponseHelper;
import com.sf.erui.context.UserContext;
import com.sf.erui.util.Assert;
import com.sfa.sfopen.demo.controller.dto.OrgReq;
import com.sfa.sfopen.demo.domain.test.EmpDo;
import com.sfa.sfopen.demo.domain.test.OrgDo;
import com.sfa.sfopen.demo.service.test.TestService;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.spring.web.json.Json;

/**
 * Controller层的主要职责主要是对访问控制进行转发，各类基本参数校验，或者不复用的业务简单处理等。
 * controller类的@RequestMapping统一使用模块名来命名,特殊情况除外
 * controller类的方法的@RequestMapping统一使用功能编码来命名,一个功能编码对应一个功能。
 *
 * @author 197370
 *
 */
@RequestMapping("test")
@Controller
public class TestController {

    private Logger logger = LoggerFactory.getLogger(TestController.class);

    @Autowired
    private TestService service;

    /**
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("queryTestPost")
    @ResponseBody
    @ApiOperation(value = "查询页面", notes = "hah")
    public Response queryTestForPost(@RequestBody OrgReq req) {

        String userName = UserContext.getCurrentUserName();
		/* 前端框架会接住此异常信息，并提示给用户 */
        Assert.notNull("用户名不能为空");

		/* 获取单个对象的方法用get做前缀。 */
        EmpDo empInfo = service.getEmpInfo(userName);
        if (empInfo != null) {
			/* do something .... */
            logger.debug(empInfo.toString());
        }

        startPage(req.getCurrentPage(), req.getPageSize());
		/* 获取多个对象的方法用list做前缀 */
        List<OrgDo> orgList = service.listOrg();
        PageInfo<OrgDo> records = new PageInfo<OrgDo>(orgList);
        if (records.getSize() > 0) {
			/* do something .... */
            logger.debug(records.toString());
        }
        return ResponseHelper.buildOk(empInfo);
    }

    @RequestMapping("/handle")
    public ResponseEntity<Json> handle() throws URISyntaxException {
        return new ResponseEntity<>(new Json("{name:Hello World}"), HttpStatus.OK);
    }

    /**
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("queryTestGet")
    @ResponseBody
    public Response queryTestForGet(HttpServletRequest request,
                                    HttpServletResponse response) {

        String userName = UserContext.getCurrentUserName();
		/* 前端框架会接住此异常信息，并提示给用户 */
        Assert.notNull(userName, "用户名不能为空");

		/* 获取单个对象的方法用get做前缀。 */
        EmpDo empInfo = service.getEmpInfo(userName);
        if (empInfo != null) {
			/* do something .... */
            logger.debug(empInfo.toString());
        }
        String currentPage = request.getParameter("currentPage");
        String pageSize = request.getParameter("pageSize");

        startPage(currentPage, pageSize);
		/* 获取多个对象的方法用list做前缀 */
        List<OrgDo> orgList = service.listOrg();
        PageInfo<OrgDo> records = new PageInfo<>(orgList);
        return ResponseHelper.buildOk(records);
    }

    private void startPage(String pageNum, String pageSize) {
        if (pageNum == null || "".equals(pageNum)) {
            pageNum = "1";
        }
        if (pageSize == null || "".equals(pageSize)) {
            pageSize = "10";
        }
        PageHelper.startPage(Integer.parseInt(pageNum),
                Integer.parseInt(pageSize));
    }

    private void startPage(Integer pageNum, Integer pageSize) {
        if (pageNum == null) {
            pageNum = 1;
        }
        if (pageSize == null) {
            pageSize = 10;
        }
        PageHelper.startPage(pageNum, pageSize);
    }
}