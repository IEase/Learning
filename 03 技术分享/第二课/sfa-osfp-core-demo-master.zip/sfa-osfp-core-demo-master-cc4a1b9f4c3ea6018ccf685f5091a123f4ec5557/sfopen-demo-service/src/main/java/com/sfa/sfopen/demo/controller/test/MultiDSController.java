package com.sfa.sfopen.demo.controller.test;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sf.erui.common.response.Response;
import com.sf.erui.common.response.ResponseHelper;
import com.sf.erui.context.UserContext;
import com.sf.erui.mybatis.support.MultipleDataSourceHolder;
import com.sf.erui.util.Assert;
import com.sfa.sfopen.demo.domain.test.TableMeta;
import com.sfa.sfopen.demo.service.test.MultiDsService;

@RequestMapping("mds")
@Controller
public class MultiDSController {

	private Logger logger = LoggerFactory.getLogger(MultiDSController.class);

	@Autowired
	private MultiDsService service;

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("queryTabsGet")
	@ResponseBody
	public Response queryTestForGet(HttpServletRequest request,
			HttpServletResponse response) {
		String key=request.getParameter("type");
		String userName = UserContext.getCurrentUserName();
		/* 前端框架会接住此异常信息，并提示给用户 */
		Assert.notNull(userName, "用户名不能为空");
		String sql = "";
		if("sfopen-demoOra".equals(key)){
			MultipleDataSourceHolder.setContextType("sfopen-demoOra");
			sql="select table_name from tabs";
		}else if("default".equals(key)){
			MultipleDataSourceHolder.setContextType("default");
			sql="select table_name from  INFORMATION_SCHEMA.TABLES";
		}
		
		startPage(1, 20);
		/* 获取单个对象的方法用get做前缀。 */
		List<TableMeta> metas = service.queryTabs(sql);
		PageInfo<TableMeta> records = new PageInfo<TableMeta>(metas);
		return ResponseHelper.buildOk(records);
	}
	
	private void startPage(Integer pageNum, Integer pageSize) {
		if (pageNum == null) {
			pageNum = 1;
		}
		if (pageSize == null) {
			pageSize = 10;
		}
		PageHelper.startPage(pageNum, pageSize);
	}
}
