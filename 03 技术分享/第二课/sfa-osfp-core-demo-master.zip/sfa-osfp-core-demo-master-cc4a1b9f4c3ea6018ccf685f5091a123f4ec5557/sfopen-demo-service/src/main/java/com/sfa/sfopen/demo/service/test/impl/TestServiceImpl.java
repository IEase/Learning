package com.sfa.sfopen.demo.service.test.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sfa.sfopen.demo.domain.test.EmpDo;
import com.sfa.sfopen.demo.domain.test.OrgDo;
import com.sfa.sfopen.demo.manager.test.TestManager;
import com.sfa.sfopen.demo.mapper.test.TestMapper;
import com.sfa.sfopen.demo.service.test.TestService;

@Service
public class TestServiceImpl implements TestService {

    @Autowired
    private TestMapper mapper;

    @Autowired
    private TestManager manager;



    @Override
    public EmpDo getEmpInfo(String userName) {

        EmpDo emp= mapper.getEmpInfo(userName);
        return emp;
    }

    @Override
    public List<OrgDo> listOrg() {
        return manager.listRegionOrg();
    }

}