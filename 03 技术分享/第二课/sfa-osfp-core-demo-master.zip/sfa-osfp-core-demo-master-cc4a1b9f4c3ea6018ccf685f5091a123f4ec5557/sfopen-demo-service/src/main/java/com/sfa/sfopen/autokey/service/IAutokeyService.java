/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */
package com.sfa.sfopen.autokey.service;

import com.sfa.sfopen.autokey.domain.Autokey;

/**
 * 编码定义接口类
 * @author 01374973
 *
 */
public interface IAutokeyService {

    /**
     * 查询编号生成规则
     * @param module    模块
     * @param name      编号名称
     * @param model     机型
     * @param ata       ata
     * @return 编号生成规则
     */
    Autokey queryAutokey(String module, String name, String model, String ata);


    /**
     * 根据module和name获取新的编号
     *
     * @param module 模块名称
     * @param name 编号名称
     * @return 新编号
     */
    String genNo(String module, String name);

    /**
     * 根据module和name，model,ata生成新的编号
     *
     * @param module 模块名称
     * @param name 编号名称
     * @param model 机型
     * @param ata ATA
     * @return 新编号
     */
    String genNoByModel(String module, String name, String model, String ata);

    /**
     * 根据某条编号规则autokey中的信息产生编号
     *
     * @param autokey  编号生成规则
     * @return 新编号
     */
    String genNo(Autokey autokey);

    /**
     * 保存编号生成规则
     *
     * @param autokey 编号生成规则
     * @return 是否成功
     */
    boolean save(Autokey autokey);

    /**
     * 删除编号生成规则
     *
     * @param autokey   编号生成规则
     */
    void delete(Autokey autokey);

    /**
     * 根据id获取某条编号生成规则
     *
     * @param id 编号生成规则ID
     * @return 编号生成规则
     */
    Autokey findAutokeyById(String id) throws Exception;

    /**
     * 生成当前seed对应的编号！！！不用做加1或者初始化判断
     *
     * @param autokey 编号生成规则
     * @return 编号生成规则
     */
    Autokey generatorCurno(Autokey autokey);

    /* public List<ZtreeNode> getModels(String key); */


}
