package com.sfa.sfopen.demo.controller.dto;


public class OrgReq  extends BaseReq{

	

	
	/*默认查询所有的组织*/
	public static final String DEF_REGION = "all";
	
	/**
	 * 父节点的ID
	 */
	private String parentID;
	
	/**
	 * 组织架构的数据范围
	 * all:查询所有的组织
	 * region:区部组织
	 * head:总部组织
	 * tech:顺丰科技组织	
	 */
	private String region;
	
	
	
	/**
	 * 预留字段 根据关键字查询组织
	 */
	private String likeStr;
	

	public String getParentID() {
		return parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}


	public String getLikeStr() {
		return likeStr;
	}

	public void setLikeStr(String likeStr) {
		this.likeStr = likeStr;
	}

 
	
	
	
}
