package com.sfa.sfopen.demo.service.test.bo;

import java.util.ArrayList;
import java.util.List;

import com.sf.erui.index.dto.Org;


public class OrgBo  {
    private Long orgId;

    private Long orgIdParent;

    private String orgName;

    private String orgType;

    private String netCode;

    private String orgCode;

    private String zhrzzcj;

	private List<Org> children = new ArrayList<Org>();
	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Long getOrgIdParent() {
		return orgIdParent;
	}

	public void setOrgIdParent(Long orgIdParent) {
		this.orgIdParent = orgIdParent;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getNetCode() {
		return netCode;
	}

	public void setNetCode(String netCode) {
		this.netCode = netCode;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getZhrzzcj() {
		return zhrzzcj;
	}

	public void setZhrzzcj(String zhrzzcj) {
		this.zhrzzcj = zhrzzcj;
	}

	public List<Org> getChildren() {
		return children;
	}

	public void setChildren(List<Org> children) {
		this.children = children;
	}
}