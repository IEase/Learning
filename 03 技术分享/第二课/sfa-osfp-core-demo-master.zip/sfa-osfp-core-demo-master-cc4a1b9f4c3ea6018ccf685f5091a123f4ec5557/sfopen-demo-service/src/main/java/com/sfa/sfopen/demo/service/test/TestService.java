package com.sfa.sfopen.demo.service.test;

import java.util.List;

import com.sfa.sfopen.demo.domain.test.EmpDo;
import com.sfa.sfopen.demo.domain.test.OrgDo;

public interface TestService {

	public EmpDo getEmpInfo(String userName);

	public List<OrgDo> listOrg(); 

}
