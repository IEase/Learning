/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;

import java.util.HashMap;
import java.util.Map;

/**
 * 编号生成器工厂
 *
 * @author 刘志(667096)
 * @create 2018/8/29
 * @since 1.0.0
 */
public class AutokeyGeneratorFactory {

    private static final Map<Integer, IAutokeyGenerator> generatorMap = new HashMap<>();

    /**
     * 获取编号对应的产生编号的方法类
     *
     * @param rule  编号规则
     * @return 编号生成器
     */
    public static IAutokeyGenerator getInstance(int rule) {
        return generatorMap.get(rule);
    }

    /**
     * 将产生编号的方法绑定对应的rule,注册到工厂中
     *
     * @param generator 编号生成器
     */
    static void register(IAutokeyGenerator generator) {
        generatorMap.put(generator.getRule(), generator);
    }
}
