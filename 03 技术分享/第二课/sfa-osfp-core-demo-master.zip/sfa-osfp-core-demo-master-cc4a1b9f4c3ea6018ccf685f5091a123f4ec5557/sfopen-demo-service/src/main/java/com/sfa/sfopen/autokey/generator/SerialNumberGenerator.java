/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 * @Author 刘志(667096)
 */

package com.sfa.sfopen.autokey.generator;

import com.sfa.sfopen.autokey.domain.Autokey;
import org.springframework.stereotype.Service;

/**
 * 前缀+流水号+后缀生成编号
 *
 * @author 刘志(667096)
 * @create 2018/8/29
 * @since 1.0.0
 */

@Service public class SerialNumberGenerator extends AbstractAutokeyGenerator {

    public int getRule() {
        return Autokey.RULE_SERIAL;
    }

    @Override public Autokey generator(Autokey autokey) {
        String seed = increaseSeed(autokey.getSeed());
        String no = generateNo(autokey, seed);
        return resetAutokey(autokey, seed, no);
    }
}