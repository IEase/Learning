/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.mapper.test;

import com.sfa.sfopen.demo.domain.test.SysConf;
import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * @author 01163853
 *
 */
public interface DemoMapper {

    /**
     * 按ID查询
     * @param confKey
     * @return
     */
    SysConf selectByPrimaryKey(@Param("confKey") String confKey);
    
    /**
     * 按ID删除
     * @param confKey
     * @return
     */
    int deleteByPrimaryKey(@Param("confKey") String confKey);
    
    /**
     * 新增
     * @param conf
     * @return
     */
    int insert(SysConf conf);
    
    /**
     * 修改
     * @param conf
     * @return
     */
    int updateByPrimaryKeySelective(SysConf conf);
    
    /**
     * 修改
     * @param conf
     * @return
     */
    int updateByPrimaryKey(SysConf conf);
    
    /**
     * 按条件查询
     * @param conf
     * @return
     */
    List<SysConf> selectByParam(SysConf conf);
}
