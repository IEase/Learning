/*
 * Copyright (c) 2018-2020 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */

package com.sfa.sfopen.demo.domain.test;

import java.util.ArrayList;
import java.util.List;



public class OrgDo  {
    private Long orgId;

    private Long orgIdParent;

    private String orgName;

    private String orgType;

    private String netCode;

    private String orgCode;

    private String zhrzzcj;

    private List<OrgDo> children = new ArrayList<>();
	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Long getOrgIdParent() {
		return orgIdParent;
	}

	public void setOrgIdParent(Long orgIdParent) {
		this.orgIdParent = orgIdParent;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getNetCode() {
		return netCode;
	}

	public void setNetCode(String netCode) {
		this.netCode = netCode;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getZhrzzcj() {
		return zhrzzcj;
	}

	public void setZhrzzcj(String zhrzzcj) {
		this.zhrzzcj = zhrzzcj;
	}

	public List<OrgDo> getChildren() {
		return children;
	}

	public void setChildren(List<OrgDo> children) {
		this.children = children;
	}
}