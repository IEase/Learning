package com.sfa.sfopen.demo.mapper.test;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfa.sfopen.demo.domain.test.TableMeta;

public interface MultiDsMapper {
 
	List<TableMeta> queryTabs(@Param("sql")String sql);

}
