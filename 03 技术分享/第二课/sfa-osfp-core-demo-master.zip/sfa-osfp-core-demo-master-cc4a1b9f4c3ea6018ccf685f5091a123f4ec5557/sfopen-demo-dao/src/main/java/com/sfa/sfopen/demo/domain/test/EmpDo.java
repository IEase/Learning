package com.sfa.sfopen.demo.domain.test;

public class EmpDo {
    private Long empId;
    
    private String empNum;
    
    private String lastName;

    private Long currOrgId;

    private String netCode;

    private String currOrgName;

    private String zhrzzqc;

    private String orgCode;

    private Long positionId;

    private String positionName;

    private String jobId;

    private String jobName;
 

    public String getEmpNum() {
        return empNum;
    }

    public void setEmpNum(String empNum) {
        this.empNum = empNum == null ? null : empNum.trim();
    }

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName == null ? null : lastName.trim();
    }

 
    public Long getCurrOrgId() {
        return currOrgId;
    }

    public void setCurrOrgId(Long currOrgId) {
        this.currOrgId = currOrgId;
    }

    public String getNetCode() {
        return netCode;
    }

    public void setNetCode(String netCode) {
        this.netCode = netCode == null ? null : netCode.trim();
    }

    public String getCurrOrgName() {
        return currOrgName;
    }

    public void setCurrOrgName(String currOrgName) {
        this.currOrgName = currOrgName == null ? null : currOrgName.trim();
    }

    public String getZhrzzqc() {
        return zhrzzqc;
    }

    public void setZhrzzqc(String zhrzzqc) {
        this.zhrzzqc = zhrzzqc == null ? null : zhrzzqc.trim();
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode == null ? null : orgCode.trim();
    }

    public Long getPositionId() {
        return positionId;
    }

    public void setPositionId(Long positionId) {
        this.positionId = positionId;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName == null ? null : positionName.trim();
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId == null ? null : jobId.trim();
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName == null ? null : jobName.trim();
    }

}
