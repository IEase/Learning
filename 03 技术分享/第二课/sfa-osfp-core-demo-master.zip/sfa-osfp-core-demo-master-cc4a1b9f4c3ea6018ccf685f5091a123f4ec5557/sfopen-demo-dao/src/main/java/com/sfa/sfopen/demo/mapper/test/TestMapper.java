package com.sfa.sfopen.demo.mapper.test;

import java.util.List;

import com.sfa.sfopen.demo.domain.test.EmpDo;
import com.sfa.sfopen.demo.domain.test.OrgDo;

public interface TestMapper {

	EmpDo getEmpInfo(String userName); 

	List<OrgDo> listOrg(String model);
}
