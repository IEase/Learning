package com.sfa.sfopen.qrcode.mapper;

import com.sfa.sfopen.qrcode.domain.QrCode;
import com.sfa.sfopen.qrcode.domain.QrCodeExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QrCodeMapper {

    int insert(QrCode record);

    int insertSelective(QrCode record);


    QrCode queryQrCodeByEntityId(String entityId);

    List<QrCode> selectByExampleWithBLOBs(QrCodeExample example);

    List<QrCode> selectByExample(QrCodeExample example);

    int updateByExampleSelective(@Param("record") QrCode record, @Param("example") QrCodeExample example);

    int updateByExampleWithBLOBs(@Param("record") QrCode record, @Param("example") QrCodeExample example);

    int updateByExample(@Param("record") QrCode record, @Param("example") QrCodeExample example);
}