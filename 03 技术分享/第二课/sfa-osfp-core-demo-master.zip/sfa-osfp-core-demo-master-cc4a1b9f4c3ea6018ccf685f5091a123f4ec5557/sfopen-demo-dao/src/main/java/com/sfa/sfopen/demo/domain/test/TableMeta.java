package com.sfa.sfopen.demo.domain.test;

public class TableMeta {
	
	private String tableName;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	
	
}

