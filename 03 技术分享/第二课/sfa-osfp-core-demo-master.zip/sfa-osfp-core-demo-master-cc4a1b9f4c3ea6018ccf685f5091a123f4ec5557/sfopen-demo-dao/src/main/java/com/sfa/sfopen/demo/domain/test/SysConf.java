/*
 * Copyright 2018 SF Airlines Co., Ltd. All rights reserved.
 * 本文件仅限于顺丰航空有限公司内部传阅，禁止外泄以及用于其他的商业目的。
 */
package com.sfa.sfopen.demo.domain.test;

/**
 * @author 01163853
 *
 */
public class SysConf {

    private String confKey;
    private String confValue;
    private String confDesc;
    private Boolean enabled;

    /**
     * @return the confKey
     */
    public String getConfKey() {
        return confKey;
    }

    /**
     * @param confKey
     *            the confKey to set
     */
    public void setConfKey(String confKey) {
        this.confKey = confKey;
    }

    /**
     * @return the confValue
     */
    public String getConfValue() {
        return confValue;
    }

    /**
     * @param confValue
     *            the confValue to set
     */
    public void setConfValue(String confValue) {
        this.confValue = confValue;
    }

    /**
     * @return the confDesc
     */
    public String getConfDesc() {
        return confDesc;
    }

    /**
     * @param confDesc
     *            the confDesc to set
     */
    public void setConfDesc(String confDesc) {
        this.confDesc = confDesc;
    }

    /**
     * @return the enabled
     */
    public Boolean getEnabled() {
        return enabled;
    }

    /**
     * @param enabled
     *            the enabled to set
     */
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SysConf [confKey=" + confKey + ", confValue=" + confValue + ", confDesc=" + confDesc + ", enabled="
                + enabled + "]";
    }

}
