-- Create table 2018-09-26
--部门表
--01372947 khz
create table TS_DEPARTMENT
(
  depart_id        NUMBER(19) not null,
  depart_id_parent NUMBER(19),
  depart_name      VARCHAR2(200) not null,
  depart_code      VARCHAR2(30),
  depart_desc      VARCHAR2(200),
  sort             NUMBER(19),
  node_level       VARCHAR2(150) not null,
  company_id       NUMBER(19) default 10001267,
  ext1             VARCHAR2(50),
  ext2             VARCHAR2(50),
  modifier_user    VARCHAR2(30) default 'BSC',
  modify_tm        DATE default sysdate,
  creator_user     VARCHAR2(30) default 'BSC',
  create_tm        DATE default sysdate
);
-- Add comments to the table 
comment on table TS_DEPARTMENT
  is '部门管理';
-- Add comments to the columns 
comment on column TS_DEPARTMENT.depart_id
  is '部门id';
comment on column TS_DEPARTMENT.depart_id_parent
  is '父组织ID';
comment on column TS_DEPARTMENT.depart_name
  is '部门名称';
comment on column TS_DEPARTMENT.depart_code
  is '部门编码';
comment on column TS_DEPARTMENT.depart_desc
  is '部门描述';
comment on column TS_DEPARTMENT.sort
  is '部门排序';
comment on column TS_DEPARTMENT.node_level
  is '节点层级';
comment on column TS_DEPARTMENT.company_id
  is '公司id';
comment on column TS_DEPARTMENT.ext1
  is '扩展字段1';
comment on column TS_DEPARTMENT.ext2
  is '扩展字段2';
comment on column TS_DEPARTMENT.modifier_user
  is '修改人';
comment on column TS_DEPARTMENT.modify_tm
  is '修改时间';
comment on column TS_DEPARTMENT.creator_user
  is '创建人';
comment on column TS_DEPARTMENT.create_tm
  is '创建时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TS_DEPARTMENT
  add constraint PK_TS_DEPARTMENT primary key (DEPART_ID)
  using index ;
