-- Create table
--岗位表
--01372947 khz
create table TS_POSITION
(
  position_id   NUMBER(19) not null,
  position_name VARCHAR2(30) not null,
  position_desc VARCHAR2(50),
  status        CHAR(1) default 1 not null,
  ext1          VARCHAR2(50),
  ext2          VARCHAR2(50),
  modifier_user VARCHAR2(30),
  modify_tm     DATE default sysdate,
  creator_user  VARCHAR2(30),
  create_tm     DATE default sysdate
);
-- Add comments to the table 
comment on table TS_POSITION
  is '用户岗位';
-- Add comments to the columns 
comment on column TS_POSITION.position_id
  is '岗位id';
comment on column TS_POSITION.position_name
  is '职位名称';
comment on column TS_POSITION.position_desc
  is '职位描述';
comment on column TS_POSITION.status
  is '状态0无效1有效';
comment on column TS_POSITION.ext1
  is '扩展1';
comment on column TS_POSITION.ext2
  is '扩展2';
comment on column TS_POSITION.modifier_user
  is '修改人';
comment on column TS_POSITION.modify_tm
  is '修改时间';
comment on column TS_POSITION.creator_user
  is '创建人';
comment on column TS_POSITION.create_tm
  is '创建时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TS_POSITION
  add constraint PK_TS_POSITION primary key (POSITION_ID)
  using index ;
