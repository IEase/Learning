-- Create table 2018-09-26
--公司表
--01372947 khz
create table TS_COMPANY
(
  company_id    NUMBER(19) not null,
  company_name  VARCHAR2(100) not null,
  company_sbh   VARCHAR2(20),
  company_addr  VARCHAR2(200),
  company_phone VARCHAR2(20),
  status        CHAR(1) default 1 not null,
  active_tm     DATE not null,
  deactive_tm   DATE not null,
  creator_user  VARCHAR2(30),
  create_tm     DATE default sysdate not null,
  modifier_user VARCHAR2(30),
  modify_tm     DATE default sysdate not null
);
-- Add comments to the table 
comment on table TS_COMPANY
  is ' 公司字典表';
-- Add comments to the columns 
comment on column TS_COMPANY.company_id
  is '公司id';
comment on column TS_COMPANY.company_name
  is '公司名称';
comment on column TS_COMPANY.company_sbh
  is '公司识别号';
comment on column TS_COMPANY.company_addr
  is '公司地址';
comment on column TS_COMPANY.company_phone
  is '公司电话';
comment on column TS_COMPANY.status
  is '状态0无效，1有效';
comment on column TS_COMPANY.active_tm
  is '启用时间';
comment on column TS_COMPANY.deactive_tm
  is '停用时间';
comment on column TS_COMPANY.creator_user
  is '创建人';
comment on column TS_COMPANY.create_tm
  is '创建时间';
comment on column TS_COMPANY.modifier_user
  is '修改人';
comment on column TS_COMPANY.modify_tm
  is '修改时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TS_COMPANY
  add constraint PK_TS_COMPANY primary key (COMPANY_ID)
  using index ;
