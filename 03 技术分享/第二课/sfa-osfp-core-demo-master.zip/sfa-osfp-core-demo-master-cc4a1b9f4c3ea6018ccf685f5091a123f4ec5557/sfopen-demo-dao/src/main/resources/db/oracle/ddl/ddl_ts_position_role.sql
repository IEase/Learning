-- Create table
--岗位角色关联表
--01372947 khz
create table TS_POSITION_ROLE
(
  position_role_id NUMBER(19) not null,
  role_id          NUMBER(19) not null,
  position_id      NUMBER(19) not null,
  modifier_user    VARCHAR2(30),
  modify_tm        DATE default sysdate,
  creator_user     VARCHAR2(30),
  create_tm        DATE default sysdate
);
-- Add comments to the table 
comment on table TS_POSITION_ROLE
  is '岗位角色关联';
-- Add comments to the columns 
comment on column TS_POSITION_ROLE.position_role_id
  is '岗位角色关联id';
comment on column TS_POSITION_ROLE.role_id
  is '角色id';
comment on column TS_POSITION_ROLE.position_id
  is '岗位id';
comment on column TS_POSITION_ROLE.modifier_user
  is '修改人';
comment on column TS_POSITION_ROLE.modify_tm
  is '修改时间';
comment on column TS_POSITION_ROLE.creator_user
  is '创建人';
comment on column TS_POSITION_ROLE.create_tm
  is '创建时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TS_POSITION_ROLE
  add constraint PK_TS_POSITION_ROLE primary key (POSITION_ROLE_ID)
  using index ;
