-- Create table 2018-09-26
--初始化表
--01163853 hj
create table TS_DICTIONARY
(
  DIC_ID    NUMBER(20),
  DIC_KEY   VARCHAR2(100),
  DIC_NAME  VARCHAR2(300),
  DESCRIPT  VARCHAR2(1200),
  PARENT_ID NUMBER(20),
  DIC_VALUE VARCHAR2(1000),
  SN        NUMBER(10),
  PKEY_PATH VARCHAR2(2000),
  STATUS    NUMBER(1),
  CREATE_BY VARCHAR2(30),
  CREATE_TM DATE DEFAULT sysdate,
  UPDATE_BY VARCHAR2(30),
  UPDATE_TM DATE DEFAULT sysdate
);
comment on column TS_DICTIONARY.DIC_ID
  is '字典ID';
comment on column TS_DICTIONARY.DIC_KEY
  is 'KEY，英文数字下划线组成';
comment on column TS_DICTIONARY.DIC_NAME
  is '名称，默认用于展示的文字';
comment on column TS_DICTIONARY.DESCRIPT
  is '描述文字';
comment on column TS_DICTIONARY.PARENT_ID
  is '父ID';
comment on column TS_DICTIONARY.DIC_VALUE
  is '值';
comment on column TS_DICTIONARY.SN
  is '序号';
comment on column TS_DICTIONARY.PKEY_PATH
  is '节点Key路径';
comment on column TS_DICTIONARY.STATUS
  is '状态：无效0，有效1';
comment on column TS_DICTIONARY.CREATE_BY
  is '创建者用户账号';
comment on column TS_DICTIONARY.CREATE_TM
  is '创建时间';
comment on column TS_DICTIONARY.UPDATE_BY
  is '更新者用户账号';
comment on column TS_DICTIONARY.UPDATE_TM
  is '更新时间';

create table TS_MODULE
(
  MODULE_ID   NUMBER(20) not null,
  PARENT_ID   NUMBER(20),
  MODULE_NAME VARCHAR2(100) not null,
  MODULE_CODE VARCHAR2(100),
  SYS_CODE    VARCHAR2(100),
  MODULE_DESC VARCHAR2(600),
  MODULE_ICON VARCHAR2(300),
  MODULE_TYPE NUMBER(1),
  APP_TYPE    NUMBER(1),
  ACTION_URL  VARCHAR2(300),
  SORT        NUMBER(20),
  HELP_URL    VARCHAR2(300),
  NODE_LEVEL  NUMBER(20),
  HIDDEN CHAR(1 BYTE) DEFAULT 'N'  NOT NULL
);
comment on column TS_MODULE.MODULE_ID
  is '功能模块ID';
comment on column TS_MODULE.PARENT_ID
  is '父功能模块ID';
comment on column TS_MODULE.MODULE_NAME
  is '名称，默认用于展示的文字';
comment on column TS_MODULE.MODULE_CODE
  is '模块代码，英文数字下划线组成';
comment on column TS_MODULE.SYS_CODE
  is '系统编码，英文数字下划线组成';
comment on column TS_MODULE.MODULE_DESC
  is '描述文字';
comment on column TS_MODULE.MODULE_ICON
  is '图标，相对根路径的地址，或者外链';
comment on column TS_MODULE.MODULE_TYPE
  is '类型 1项目根类型 2子系统  3菜单目录 4页面按钮，权限等';
comment on column TS_MODULE.APP_TYPE
  is '功能类型 1.PC WEB 2.手机WEB';
comment on column TS_MODULE.ACTION_URL
  is '功能请求链接，相对根路径的地址';
comment on column TS_MODULE.SORT
  is '排序序号';
comment on column TS_MODULE.HELP_URL
  is '帮助链接，相对根路径的地址，或者外链';
comment on column TS_MODULE.NODE_LEVEL
  is '节点层级';
alter table TS_MODULE
  add constraint PK_TS_MODULE primary key (MODULE_ID);
alter table TS_MODULE
  add constraint UN_SYSCODE_MODULECODE unique (SYS_CODE, MODULE_CODE);
create index KEY_PARENT_ID on TS_MODULE (PARENT_ID);

create table TS_OP_LOG
(
  LOG_ID        NUMBER(20) not null,
  OP_MODULE     VARCHAR2(128),
  USER_ID       NUMBER(11),
  USER_NAME     VARCHAR2(128),
  OP_TYPE       CHAR(8),
  OP_PARAM      VARCHAR2(1024),
  OP_CONTENT    VARCHAR2(1024),
  SERVICE_IP    NUMBER(11),
  SOURCE        CHAR(4),
  MEMO          VARCHAR2(1024),
  EXT1          VARCHAR2(128),
  EXT2          VARCHAR2(128),
  EXT3          VARCHAR2(128),
  USER_EXT_INFO VARCHAR2(128),
  OP_HOST_NAME  VARCHAR2(128),
  OP_IP         NUMBER(11),
  OP_TM         DATE DEFAULT sysdate
);
comment on column TS_OP_LOG.LOG_ID
  is '主键';
comment on column TS_OP_LOG.OP_MODULE
  is '操作模块';
comment on column TS_OP_LOG.USER_ID
  is '用户ID';
comment on column TS_OP_LOG.USER_NAME
  is '用户名';
comment on column TS_OP_LOG.OP_TYPE
  is '操作类型，CRT创建，DEL删除，UPD修改，GET查看，LOGIN 登录，LOGOUT 登出，DATAIN 导入，DATAOUT 导出，OT其他';
comment on column TS_OP_LOG.OP_PARAM
  is '操作参数';
comment on column TS_OP_LOG.OP_CONTENT
  is '操作内容';
comment on column TS_OP_LOG.SERVICE_IP
  is '提供服务，机器ip ,ip2long';
comment on column TS_OP_LOG.SOURCE
  is '操作来源，W-web，A-android，S-ios,X-weixin';
comment on column TS_OP_LOG.MEMO
  is '备注';
comment on column TS_OP_LOG.EXT1
  is '扩展用';
comment on column TS_OP_LOG.EXT2
  is '扩展用';
comment on column TS_OP_LOG.EXT3
  is '扩展用';
comment on column TS_OP_LOG.USER_EXT_INFO
  is '用户附加信息';
comment on column TS_OP_LOG.OP_HOST_NAME
  is '操作者主机名';
comment on column TS_OP_LOG.OP_IP
  is '操作ID';
comment on column TS_OP_LOG.OP_TM
  is '操作时间';
alter table TS_OP_LOG
  add constraint PK_TS_OP_LOG primary key (LOG_ID);
create index IDX_TM_OPERATOR_TYPE on TS_OP_LOG (USER_NAME, OP_TM);

create table TS_ROLE
(
  ROLE_ID       NUMBER(19) not null,
  ROLE_CODE     VARCHAR2(100),
  ROLE_NAME     VARCHAR2(100),
  ROLE_DESC     VARCHAR2(600),
  ROLE_TYPE     NUMBER(6),
  STATUS        VARCHAR2(30),
  SYS_FLAG      NUMBER(6),
  MODIFIER_USER VARCHAR2(16),
  MODIFY_TM     DATE,
  CREATOR_USER  VARCHAR2(16),
  CREATE_TM     DATE
);
comment on column TS_ROLE.ROLE_ID
  is '角色ID';
comment on column TS_ROLE.ROLE_CODE
  is '代码，英文数字下划线组成';
comment on column TS_ROLE.ROLE_NAME
  is '名称，默认用于展示的文字';
comment on column TS_ROLE.ROLE_DESC
  is '描述文字';
comment on column TS_ROLE.ROLE_TYPE
  is '角色类型：1.ADMIN角色，2.子管理员角色 ，3.普通角色';
comment on column TS_ROLE.STATUS
  is '状态：无效0，有效1';
comment on column TS_ROLE.SYS_FLAG
  is '是否内置角色：0否，1是';
alter table TS_ROLE
  add constraint PK_TS_ROLE primary key (ROLE_ID);
alter table TS_ROLE
  add constraint ROLE_CODE unique (ROLE_CODE);

create table TS_ROLE_MODULE
(
  ROLE_ID       NUMBER(19) not null,
  MODULE_ID     NUMBER(19) not null,
  MODIFIER_USER VARCHAR2(16),
  MODIFY_TM     DATE DEFAULT sysdate
);
comment on column TS_ROLE_MODULE.ROLE_ID
  is '角色ID';
comment on column TS_ROLE_MODULE.MODULE_ID
  is '功能模块ID';
alter table TS_ROLE_MODULE
  add constraint PK_PRIMARY_ID primary key (ROLE_ID, MODULE_ID);
alter table TS_ROLE_MODULE
  add constraint PK_FOREIGN_MODULEID foreign key (MODULE_ID)
  references TS_MODULE (MODULE_ID) on delete cascade;
alter table TS_ROLE_MODULE
  add constraint PK_FOREIGN_ROLEID foreign key (ROLE_ID)
  references TS_ROLE (ROLE_ID) on delete cascade;

create table TS_USER
(
  USER_ID       NUMBER(19) not null,
  USERNAME      VARCHAR2(30),
  TYPE_CODE     CHAR(18),
  PWD           VARCHAR2(100),
  PWD_MODIFY_TM DATE,
  STATUS        VARCHAR2(30),
  ACTIVE_TM     DATE,
  DEACTIVE_TM   DATE,
  MODIFIER_USER VARCHAR2(16),
  MODIFY_TM     DATE,
  CREATOR_USER  VARCHAR2(16),
  CREATE_TM     DATE
);
comment on table TS_USER
  is '用户表';
comment on column TS_USER.USER_ID
  is '用户ID';
comment on column TS_USER.USERNAME
  is '登录名/账号';
comment on column TS_USER.TYPE_CODE
  is '用户类型编码 1-域用户账号 0-非域用户账号';
comment on column TS_USER.PWD
  is '密码，仅在自己校验是保存密码';
comment on column TS_USER.PWD_MODIFY_TM
  is '密码修改时间';
comment on column TS_USER.STATUS
  is '状态：无效0，有效1';
comment on column TS_USER.ACTIVE_TM
  is '启用时间';
comment on column TS_USER.DEACTIVE_TM
  is '停用时间';
alter table TS_USER
  add constraint PK_TS_USER primary key (USER_ID);
alter table TS_USER
  add constraint USERNAME unique (USERNAME);

create table TS_USER_ROLE
(
  ROLE_ID       NUMBER(19) not null,
  USER_ID       NUMBER(19) not null,
  IS_DEFAULT    NUMBER(6),
  SYS_CODE      VARCHAR2(100),
  EXP_DATE      DATE DEFAULT sysdate,
  MODIFIER_USER VARCHAR2(16),
  MODIFY_TM     DATE DEFAULT sysdate,
  USER_ROLE_ID  NUMBER(19) not null
);
comment on column TS_USER_ROLE.ROLE_ID
  is '用户ID';
comment on column TS_USER_ROLE.USER_ID
  is '角色ID';
comment on column TS_USER_ROLE.IS_DEFAULT
  is '是否默认角色：1是 0否';
comment on column TS_USER_ROLE.SYS_CODE
  is '系统编码，当是默认角色时，可指定系统编码';
comment on column TS_USER_ROLE.EXP_DATE
  is '过期日期，有效期至';
alter table TS_USER_ROLE
  add constraint PK_TS_USER_ROLE primary key (USER_ROLE_ID);
alter table TS_USER_ROLE
  add constraint TS_USER_ROLE_IBFK_1 foreign key (ROLE_ID)
  references TS_ROLE (ROLE_ID) on delete cascade;
alter table TS_USER_ROLE
  add constraint TS_USER_ROLE_IBFK_2 foreign key (USER_ID)
  references TS_USER (USER_ID) on delete cascade;
create index TS_USER_ROLE_IBFK_3 on TS_USER_ROLE (ROLE_ID, USER_ID, SYS_CODE);

-- Create table
create table SYS_CONF
(
  CONF_KEY   VARCHAR2(255) not null,
  CONF_VALUE VARCHAR2(255),
  CONF_DESC  VARCHAR2(255),
  ENABLED    NUMBER(1) not null
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table SYS_CONF
  add primary key (CONF_KEY);