-- Create table 2018-09-26
--初始化数据
--01163853 hj
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (27, 'SysArguSetting', '系统参数配置', null, 0, '1,2,3,4,5,6,7,8,9', 2, null, 1, '1', to_date('18-12-2015 11:47:00', 'dd-mm-yyyy hh24:mi:ss'), '5', to_date('19-08-2016 14:24:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (115, 'MailSendSetting', '邮件发送设置', null, 255, null, 2, 'BaseSetting', 1, '1', to_date('26-12-2015 18:20:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('26-12-2015 18:20:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (116, 'toControl', '收件人控制', '收件人控制，为避免测试环境的测试邮件，发送到业务人员邮箱影响业务操作，这里可设置具体的收件人(多个以逗号分隔)，以达到屏蔽测试邮件发送到业务人员的邮箱中。设置后，收件人收到的邮件内容中，可体现出实际真正的【收件人、抄送人、密送人】chenwei8@sf-express.com,houtingsong@sf-express.com,yangyuting1@sf-express.com,tangyong@sf-express.com,wang25@sf-express.com,sfit0989@sf-express.com,sfit1060@sf-express.com,sfit1066@sf-express.com,sfit1221@sf-express.com,wulili3@sf-express.com,chencx@sf-express.com,huangjing@sf-express.com', 115, 'sfuat888@sfuat.com', 1, 'BaseSetting.MailSendSetting', 1, '1', to_date('26-12-2015 18:30:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('29-12-2015 16:31:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (117, 'RoleTypes', '角色类型', '角色管理中的角色类型', 255, '角色管理中的角色类型', 3, 'BaseSetting', 1, '1', to_date('28-12-2015 14:37:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 14:37:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (118, 'NORMAL', '普通角色', '系统管理员', 117, 'NORMAL', 1, 'BaseSetting.RoleTypes', 1, '1', to_date('28-12-2015 14:38:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 14:39:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (119, 'SUB_ADMIN', '子管理员', '系统管理员', 117, 'SUB_ADMIN', 2, 'BaseSetting.RoleTypes', 1, '1', to_date('28-12-2015 14:38:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 14:39:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (120, 'ADMIN', '系统管理员', '系统管理员', 117, 'ADMIN', 3, 'BaseSetting.RoleTypes', 1, '1', to_date('28-12-2015 14:39:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 14:39:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (127, 'status_boolean', '数据状态', '数据状态', 126, null, 1, 'BaseSetting.DataStatus', 1, '1', to_date('28-12-2015 16:58:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 16:58:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (128, 'status_default', '数据状态', '数据状态', 126, null, 1, 'BaseSetting.DataStatus', 1, '1', to_date('28-12-2015 16:59:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 16:59:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (129, 'status_1', '有效', '有效', 128, '1', 1, 'BaseSetting.DataStatus.status_default', 1, '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (130, 'status_0', '无效', '无效', 128, '0', 2, 'BaseSetting.DataStatus.status_default', 1, '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (131, 'status_0', '无效', '无效', 127, 'FALSE', 2, 'BaseSetting.DataStatus.status_boolean', 1, '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 17:00:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (132, 'status_1', '有效', '有效', 127, 'TRUE', 1, 'BaseSetting.DataStatus.status_boolean', 1, '1', to_date('28-12-2015 17:01:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('28-12-2015 17:01:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (160, 'linux_path', 'linux临时文件路径', 'linux临时文件路径', 27, '/nfsc/ESG_HOS_CORE', 1, 'SysArguSetting', 1, '1', to_date('31-12-2015 15:11:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('31-12-2015 15:11:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (161, 'windows_path', 'windows临时文件路径', 'windows临时文件路径', 27, 'C:', 5, 'SysArguSetting', 1, '1', to_date('31-12-2015 15:14:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('31-12-2015 15:14:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (163, 'hos_url', '后台域网址', null, 164, 'http://localhost:8083/hos', 4, 'SysArguSetting.DomainSetting', 1, '23', to_date('06-01-2016 11:39:00', 'dd-mm-yyyy hh24:mi:ss'), '23', to_date('06-01-2016 16:32:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (164, 'DomainSetting', '域名配置', '域名配置', 27, '域名配置', 1, 'SysArguSetting', 1, '23', to_date('06-01-2016 11:40:00', 'dd-mm-yyyy hh24:mi:ss'), '23', to_date('06-01-2016 16:32:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (165, 'portal_url', '前端域网址', null, 164, 'http://localhost:8083/portal', 1, 'SysArguSetting.DomainSetting', 1, '23', to_date('06-01-2016 11:43:00', 'dd-mm-yyyy hh24:mi:ss'), '23', to_date('06-01-2016 16:32:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (221, 'waitUpload', '待上传入职资料', null, 200, '5Y', 1, 'BaseSetting.joinDataStatus', 1, '1', to_date('15-01-2016 14:35:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('15-01-2016 14:35:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (222, 'giveUpUpload', '放弃上传入职资料', null, 200, '5D', 2, 'BaseSetting.joinDataStatus', 1, '1', to_date('15-01-2016 14:35:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('15-01-2016 14:35:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (223, 'upUploadOver', '上传审核不通过', null, 200, '5N', 3, 'BaseSetting.joinDataStatus', 1, '1', to_date('15-01-2016 14:45:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('15-01-2016 14:45:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (224, 'waitEntrance', '入司资料审核通过', null, 200, '6Y', 4, 'BaseSetting.joinDataStatus', 1, '1', to_date('15-01-2016 14:46:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('15-01-2016 14:46:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (241, 'SysCode', '系统编码', null, 27, 'ESG-HOS-CORE', 7, 'SysArguSetting', 1, '23', to_date('16-01-2016 16:58:00', 'dd-mm-yyyy hh24:mi:ss'), '23', to_date('16-01-2016 16:58:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (249, 'templateTypes', '模板类型列表', null, 255, null, 9, 'BaseSetting', 1, '1', to_date('30-01-2016 17:34:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('30-01-2016 17:34:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (250, 'MailTemplate', '邮件模板', '邮件模板', 249, '1', 1, 'BaseSetting.templateTypes', 1, '1', to_date('30-01-2016 17:34:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('30-01-2016 17:34:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (251, 'MessagingTemplate', '短信模板', '短信模板', 249, '2', 2, 'BaseSetting.templateTypes', 1, '1', to_date('30-01-2016 17:37:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('30-01-2016 17:37:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (255, 'BaseSetting', '基础配置项test', '框架自带的基础配置项', 0, null, 1, null, 1, '5', to_date('09-02-2017 03:28:00', 'dd-mm-yyyy hh24:mi:ss'), '5', to_date('09-02-2017 03:28:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (256, 'demo_Setting', '示例字典集合', '示例字典集合', 0, null, 3, null, 1, '5', to_date('19-08-2016 15:03:00', 'dd-mm-yyyy hh24:mi:ss'), '5', to_date('19-08-2016 15:03:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (257, 'collectType', '搜集类型', null, 256, null, 1, 'demo_Setting', 1, '5', to_date('19-08-2016 15:05:00', 'dd-mm-yyyy hh24:mi:ss'), '5', to_date('19-08-2016 15:05:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (258, 'type1', '类型1', null, 257, '1', 1, 'demo_Setting.collectType', 1, '5', to_date('19-08-2016 15:07:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:09:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (259, 'type2', '类型2', null, 257, '2', 2, 'demo_Setting.collectType', 1, '5', to_date('19-08-2016 15:09:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:09:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (261, 'level', '等级', '等级', 256, null, 2, 'demo_Setting', 1, '1', to_date('19-09-2016 18:00:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:00:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (262, 'level_1', '高', null, 261, '1', 1, 'demo_Setting.level', 1, '1', to_date('19-09-2016 18:02:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:07:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (263, 'level2', '中', null, 261, '2', 2, 'demo_Setting.level', 1, '1', to_date('19-09-2016 18:07:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:07:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (264, 'level3', '低', null, 261, '3', 3, 'demo_Setting.level', 1, '1', to_date('19-09-2016 18:07:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('19-09-2016 18:07:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (276, 'test', '测试角色类型', '测试角色类型', 117, 'test', 4, 'BaseSetting.RoleTypes', 1, '1', to_date('23-11-2016 12:09:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('23-11-2016 12:09:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (277, 'toControl', '2', null, 116, 'lanxing@sf-express.com', 2, 'BaseSetting.MailSendSetting.toControl', 1, '1', to_date('20-12-2016 15:39:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('20-12-2016 15:39:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (278, 'toControl', '2', null, 277, 'lanxing@sf-express.com', 2, 'BaseSetting.MailSendSetting.toControl.toControl', 1, '1', to_date('03-01-2017 16:32:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('03-01-2017 16:32:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (279, 'toControl2', '2', null, 116, 'landddddding@sf-express.com', 3, 'BaseSetting.MailSendSetting.toControl', 1, '1', to_date('03-01-2017 16:33:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('03-01-2017 16:33:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (280, 'toControl3', '2', null, 116, 'landddddding@sf-express.com', 3, 'BaseSetting.MailSendSetting.toControl', 1, '1', to_date('03-01-2017 16:33:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('03-01-2017 16:33:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (281, 'xxxxx', 'hhh', null, 117, 'hhhh', 100, 'BaseSetting.RoleTypes', 1, '1', to_date('04-01-2017 13:54:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('04-01-2017 13:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_DICTIONARY (DIC_ID, DIC_KEY, DIC_NAME, DESCRIPT, PARENT_ID, DIC_VALUE, SN, PKEY_PATH, STATUS, CREATE_BY, CREATE_TM, UPDATE_BY, UPDATE_TM)
values (284, 'level3_1', '低1', null, 264, '1', 1, 'demo_Setting.level.level3', 1, '1', to_date('17-01-2017 11:38:00', 'dd-mm-yyyy hh24:mi:ss'), '1', to_date('17-01-2017 11:38:00', 'dd-mm-yyyy hh24:mi:ss'));
commit;
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (2, 0, 'SFOPEN管理系统', 'asms', 'demo', 'demo', 'asms', 3, 1, '', 2, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (203005, 203, '系统监控', 'systemMonitoring', 'demo', '系统监控', 'systemMonitoring', 3, 1, 'systemMonitoring', 4, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (203004, 203, '数据字典', 'hos_DataDictionary', 'demo', '数据字典', 'hos_DataDictionary', 3, 1, '/dictionaryManage/index.pvt', 4, '', null, 'N'); 
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (203, 2, '后台管理', 'hos_Seting', 'demo', '后台管理', 'iconfont icon-structrue', 3, 1, '', 5, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (203006, 203, '接口联调入口', 'rap_compare', 'demo', '', '', 3, 1, '', 0, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (203007, 203, '附件管理', 'attachmentManagement', 'demo', '附件管理', '', 3, 1, '', 6, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (209, 2, '用户管理', 'hos_userManage', 'demo', '用户管理', 'iconfont icon-user', 3, 1, '', 6, 'div', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (209001, 209, '角色列表', 'hos_RoleList', 'demo', '角色列表', 'hos_RoleList', 3, 1, '/roleManage/index.pvt', 1, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (209002, 209, '用户列表', 'hos_UserList', 'demo', '用户列表', 'hos_UserList', 3, 1, '/localUser/index.pvt', 2, 'div', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (209003, 209, '功能列表', 'hos_ModuleManage', 'demo', '功能列表', 'hos_ModuleManage', 3, 1, '/module/index.pvt', 3, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, NODE_LEVEL, HIDDEN)
values (209004, 209, '岗位列表', 'position_lst', 'demo', '', '', 3, 1, '', 1, '', null, 'N');
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, HIDDEN)
values (20300401, 203004, '数据字典保存', 'hos_DataDicionary_Add', 'demo', '数据字典保存', 'hos_DataDicionary_Add', 4, 1, '/dictinaryManage/saveDictionary.pvt', 1, null, null);
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, HIDDEN)
values (20300402, 203004, '数据字典查询', 'hos_DataDicionary_query', 'demo', '数据字典查询', 'hos_DataDicionary_query', 4, 1, '/dictinaryManage/queryDictionary.pvt', 2, null, null);
insert into TS_MODULE (MODULE_ID, PARENT_ID, MODULE_NAME, MODULE_CODE, SYS_CODE, MODULE_DESC, MODULE_ICON, MODULE_TYPE, APP_TYPE, ACTION_URL, SORT, HELP_URL, HIDDEN)
values (20300403, 203004, '数据字典删除', 'hos_DataDicionary_delete', 'demo', '数据字典删除', 'hos_DataDicionary_delete', 4, 1, '/dictinaryManage/deleteDictionary.pvt', 3, null, null);
commit;
insert into TS_ROLE (ROLE_ID, ROLE_CODE, ROLE_NAME, ROLE_DESC, ROLE_TYPE, STATUS, SYS_FLAG, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (102, 'hr_Manager', '招聘管理员', '招聘管理员', '3', '1', 1, null, to_date('16-12-2015 10:55:00', 'dd-mm-yyyy hh24:mi:ss'), null, to_date('16-12-2015 10:55:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE (ROLE_ID, ROLE_CODE, ROLE_NAME, ROLE_DESC, ROLE_TYPE, STATUS, SYS_FLAG, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (103, 'admin', '系统管理员', '系统管理员', '3', '1', 1, null, to_date('16-12-2015 10:55:00', 'dd-mm-yyyy hh24:mi:ss'), '01163853', to_date('23-12-2016 06:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE (ROLE_ID, ROLE_CODE, ROLE_NAME, ROLE_DESC, ROLE_TYPE, STATUS, SYS_FLAG, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (115, 'test', '测试角色', '测试角色', '3', '1', 1, '01163853', to_date('20-02-2016 11:23:00', 'dd-mm-yyyy hh24:mi:ss'), '01163853', to_date('23-12-2016 06:31:00', 'dd-mm-yyyy hh24:mi:ss'));
commit;
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 20300402, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 20300401, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 209001, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 203004, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 209, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 203, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 112, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (115, 2, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 209002, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 209001, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 209, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 112, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 2, '01163853', to_date('16-03-2017 18:54:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 209004, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (103, 209003, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 20300403, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 20300402, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 20300401, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 209002, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 209001, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 203004, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 209, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 203, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 112, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_ROLE_MODULE (ROLE_ID, MODULE_ID, MODIFIER_USER, MODIFY_TM)
values (102, 2, '01163853', to_date('16-03-2017 18:23:00', 'dd-mm-yyyy hh24:mi:ss'));
commit;
insert into TS_USER (USER_ID, USERNAME, TYPE_CODE, PWD, PWD_MODIFY_TM, STATUS, ACTIVE_TM, DEACTIVE_TM, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (1, '01163853', '1', null, null, '1', null, null, null, to_date('26-05-2016 10:14:11', 'dd-mm-yyyy hh24:mi:ss'), null, to_date('26-05-2016 10:14:11', 'dd-mm-yyyy hh24:mi:ss'));
commit;
insert into TS_USER_ROLE (ROLE_ID, USER_ID, IS_DEFAULT, SYS_CODE, EXP_DATE, MODIFIER_USER, MODIFY_TM, USER_ROLE_ID)
values (102, 1, 1, '*', null, null, null, 1);
insert into TS_USER_ROLE (ROLE_ID, USER_ID, IS_DEFAULT, SYS_CODE, EXP_DATE, MODIFIER_USER, MODIFY_TM, USER_ROLE_ID)
values (103, 1, 1, '*', null, null, null, 2);
commit;
insert into ts_userinfo (USER_ID, POSITION_ID, NAME, SEX, MOBILE_PHONE, EMAIL, COMPANY_ID, DEPART_ID, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM, EMP_NUM)
values (1, 1, '黄京', 'M', '15814059850', 'frank5@sf-express.com', 10001267, 10019957, 'BSC', to_date('27-08-2018 14:40:37', 'dd-mm-yyyy hh24:mi:ss'), 'BSC', to_date('27-08-2018 14:40:41', 'dd-mm-yyyy hh24:mi:ss'), '01163853');
commit;
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (1, 'IT项目经理', '', '1', '', '', '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (2, 'IT研发储备', '', '1', '', '', '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (3, 'IT产品经理', '', '1', '', '', '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:23', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (4, 'IT应用运维工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (5, 'IT应用运维副工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (6, 'IT网络规划资深工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (7, 'IT网络规划工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:07', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (8, 'IT产品副工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (9, 'IT产品工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (10, 'IT产品资深工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (11, 'IT运维开发工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (12, '研发工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (13, '研发高级工程师', '', '1', '', '', '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('03-04-2018 11:18:11', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (14, '研发中级工程师Ⅱ', '', '1', '', '', '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (15, '研发中级工程师Ⅰ', '', '1', '', '', '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (16, '研发初级工程师Ⅱ', '', '1', '', '', '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'));
insert into TS_POSITION (POSITION_ID, POSITION_NAME, POSITION_DESC, STATUS, EXT1, EXT2, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (17, '研发初级工程师Ⅰ', '', '1', '', '', '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'), '', to_date('01-07-2016 00:11:17', 'dd-mm-yyyy hh24:mi:ss'));
commit;
insert into TS_POSITION_ROLE (POSITION_ROLE_ID, ROLE_ID, POSITION_ID, MODIFIER_USER, MODIFY_TM, CREATOR_USER, CREATE_TM)
values (1, 103, 1, '01163853', to_date('17-10-2018', 'dd-mm-yyyy'), '01163853', to_date('17-10-2018', 'dd-mm-yyyy'));
commit;
