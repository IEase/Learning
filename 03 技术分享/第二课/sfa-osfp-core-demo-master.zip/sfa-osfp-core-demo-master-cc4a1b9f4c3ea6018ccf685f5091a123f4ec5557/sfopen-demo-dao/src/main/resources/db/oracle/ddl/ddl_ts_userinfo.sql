-- Create table 
--人员信息表
---01372946 khz
create table TS_USERINFO
(
  user_id       NUMBER(19) not null,
  position_id   NUMBER(19) not null,
  name          VARCHAR2(30) not null,
  sex           CHAR(1) not null,
  mobile_phone  VARCHAR2(20),
  email         VARCHAR2(100),
  company_id    NUMBER(19) default 10001267 not null,
  depart_id     NUMBER(19) not null,
  modifier_user VARCHAR2(30) default 'BSC',
  modify_tm     DATE default sysdate,
  creator_user  VARCHAR2(30) default 'BSC',
  create_tm     DATE default sysdate,
  emp_num       VARCHAR2(10) not null
);
-- Add comments to the table 
comment on table TS_USERINFO
  is '人员信息表';
-- Add comments to the columns 
comment on column TS_USERINFO.user_id
  is '用户账户id';
comment on column TS_USERINFO.position_id
  is '岗位ID';
comment on column TS_USERINFO.name
  is '用户名';
comment on column TS_USERINFO.sex
  is '性别';
comment on column TS_USERINFO.mobile_phone
  is '移动电话';
comment on column TS_USERINFO.email
  is '电子邮件';
comment on column TS_USERINFO.company_id
  is '公司id';
comment on column TS_USERINFO.depart_id
  is '部门id';
comment on column TS_USERINFO.modifier_user
  is '修改人';
comment on column TS_USERINFO.modify_tm
  is '修改时间';
comment on column TS_USERINFO.creator_user
  is '创建人';
comment on column TS_USERINFO.create_tm
  is '创建时间';
-- Create/Recreate primary, unique and foreign key constraints 
alter table TS_USERINFO
  add constraint PK_TS_USERINFO primary key (USER_ID)
  using index ;
