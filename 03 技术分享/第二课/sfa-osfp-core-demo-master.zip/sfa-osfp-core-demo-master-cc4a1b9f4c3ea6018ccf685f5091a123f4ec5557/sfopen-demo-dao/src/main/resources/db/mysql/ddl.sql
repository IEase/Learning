
CREATE TABLE IF NOT EXISTS `ts_dictionary` (
  `DIC_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '字典ID',
  `DIC_KEY` varchar(100) NOT NULL COMMENT 'KEY，英文数字下划线组成',
  `DIC_NAME` varchar(300) DEFAULT NULL COMMENT '名称，默认用于展示的文字',
  `DESCRIPT` varchar(1200) DEFAULT NULL COMMENT '描述文字',
  `PARENT_ID` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `DIC_VALUE` varchar(1000) DEFAULT NULL COMMENT '值',
  `SN` int(10) DEFAULT NULL COMMENT '序号',
  `PKEY_PATH` varchar(2000) NOT NULL COMMENT '如节点Key路径',
  `STATUS` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态：无效0，有效1',
  `CREATE_BY` varchar(30) DEFAULT NULL COMMENT '创建者用户账号',
  `CREATE_TM` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `UPDATE_BY` varchar(30) DEFAULT NULL COMMENT '更新者用户账号',
  `UPDATE_TM` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`DIC_ID`),
  FULLTEXT KEY `IDX_DICTIONARY` (`DIC_KEY`,`PKEY_PATH`)
) ENGINE=InnoDB AUTO_INCREMENT=313 DEFAULT CHARSET=utf8 COMMENT='数据字典信息表';


CREATE TABLE IF NOT EXISTS `ts_module` (
  `MODULE_ID` bigint(18) unsigned NOT NULL COMMENT '功能模块ID',
  `PARENT_ID` bigint(18) unsigned DEFAULT NULL COMMENT '父功能模块ID，没有父模块时为空',
  `MODULE_NAME` varchar(120) DEFAULT NULL COMMENT '名称，默认用于展示的文字',
  `SYS_CODE` varchar(100) NOT NULL COMMENT '系统编码，英文数字下划线组成',
  `MODULE_CODE` varchar(100) NOT NULL COMMENT '模块代码，英文数字下划线组成',
  `MODULE_DESC` varchar(600) DEFAULT NULL COMMENT '描述文字',
  `MODULE_ICON` varchar(300) DEFAULT NULL COMMENT '图标，相对根路径的地址，或者外链',
  `MODULE_TYPE` tinyint(3) unsigned NOT NULL COMMENT '类型 1项目根类型 2子系统  3菜单目录 4页面按钮，权限等',
  `APP_TYPE` tinyint(3) unsigned NOT NULL COMMENT '功能类型 1.PC WEB 2.手机WEB',
  `ACTION_URL` varchar(300) DEFAULT NULL COMMENT '功能请求链接，相对根路径的地址',
  `SORT` tinyint(3) unsigned NOT NULL COMMENT '排序序号',
  `HELP_URL` varchar(300) DEFAULT NULL COMMENT '帮助链接，相对根路径的地址，或者外链',
  `HIDDEN` CHAR(1) NULL DEFAULT 'N',
  PRIMARY KEY (`MODULE_ID`),
  UNIQUE KEY `IDX_MODULE` (`SYS_CODE`(30),`MODULE_CODE`(30)) USING BTREE,
  KEY `ts_module_ibfk_1` (`PARENT_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='功能模块表';



CREATE TABLE IF NOT EXISTS `ts_role` (
  `ROLE_ID` bigint(18) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `ROLE_CODE` varchar(100) NOT NULL COMMENT '代码，英文数字下划线组成',
  `ROLE_NAME` varchar(300) DEFAULT NULL COMMENT '名称，默认用于展示的文字',
  `ROLE_DESC` varchar(1200) DEFAULT NULL COMMENT '描述文字',
  `ROLE_TYPE` tinyint(3) unsigned NOT NULL COMMENT '角色类型：1.ADMIN角色，2.子管理员角色 ，3.普通角色；',
  `SYS_FLAG` tinyint(1) unsigned DEFAULT '0' COMMENT '是否内置角色：0否，1是 ',
  `STATUS` tinyint(1) unsigned NOT NULL COMMENT '状态：无效0，有效1',
  `CREATOR_USER` varchar(30) DEFAULT NULL COMMENT '创建者用户账号',
  `CREATE_TM` datetime DEFAULT NULL COMMENT '创建时间',
  `MODIFIER_USER` varchar(30) DEFAULT NULL COMMENT '更新者用户账号',
  `MODIFY_TM` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ROLE_ID`),
  UNIQUE KEY `ROLE_CODE` (`ROLE_CODE`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COMMENT='角色表';




CREATE TABLE IF NOT EXISTS `ts_role_module` (
  `ROLE_ID` bigint(18) unsigned NOT NULL COMMENT '角色ID',
  `MODULE_ID` bigint(18) unsigned NOT NULL COMMENT '功能模块ID',
  `MODIFIER_USER` varchar(30) DEFAULT NULL COMMENT '更新者用户账号',
  `MODIFY_TM` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ROLE_ID`,`MODULE_ID`),
  KEY `MODULE_ID` (`MODULE_ID`) USING BTREE,
  CONSTRAINT `ts_role_module_ibfk_1` FOREIGN KEY (`ROLE_ID`) REFERENCES `ts_role` (`ROLE_ID`) ON DELETE CASCADE,
  CONSTRAINT `ts_role_module_ibfk_2` FOREIGN KEY (`MODULE_ID`) REFERENCES `ts_module` (`MODULE_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色功能关联表';



CREATE TABLE IF NOT EXISTS `ts_user` (
  `USER_ID` bigint(18) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `USERNAME` varchar(50) NOT NULL COMMENT '登录名/账号',
  `TYPE_CODE` tinyint(1) NOT NULL COMMENT '用户类型编码 1-域用户账号 0-非域用户账号',
  `PWD` varchar(100) DEFAULT NULL COMMENT '密码，仅在自己校验是保存密码',
  `PWD_MODIFY_TM` date DEFAULT NULL COMMENT '密码修改时间',
  `STATUS` tinyint(1) unsigned NOT NULL COMMENT '状态：无效0，有效1',
  `ACTIVE_TM` date DEFAULT NULL COMMENT '启用时间',
  `DEACTIVE_TM` date DEFAULT NULL COMMENT '停用时间',
  `MODIFIER_USER` varchar(30) DEFAULT NULL COMMENT '更新者用户账号',
  `MODIFY_TM` datetime DEFAULT NULL COMMENT '更新时间',
  `CREATOR_USER` varchar(30) DEFAULT NULL COMMENT '创建者用户账号',
  `CREATE_TM` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `USERNAME` (`USERNAME`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COMMENT='用户表';




-- 导出  表 sfopen2.ts_user_role 结构
CREATE TABLE IF NOT EXISTS `ts_user_role` (
  `USER_ROLE_ID` bigint(18) unsigned NOT NULL AUTO_INCREMENT,
  `USER_ID` bigint(18) unsigned NOT NULL COMMENT '用户ID',
  `ROLE_ID` bigint(18) unsigned NOT NULL COMMENT '角色ID',
  `IS_DEFAULT` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否默认角色：1是 0否',
  `SYS_CODE` varchar(100) NOT NULL DEFAULT '*' COMMENT '系统编码，当是默认角色时，可指定系统编码',
  `EXP_DATE` date DEFAULT NULL COMMENT '过期日期，有效期至',
  `MODIFIER_USER` varchar(30) DEFAULT NULL COMMENT '更新者用户账号',
  `MODIFY_TM` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`USER_ROLE_ID`),
  KEY `ts_user_role_ibfk_2` (`ROLE_ID`) USING BTREE,
  KEY `ts_user_role_ibfk_3` (`USER_ID`,`ROLE_ID`,`SYS_CODE`) USING BTREE,
  CONSTRAINT `ts_user_role_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `ts_user` (`USER_ID`) ON DELETE CASCADE,
  CONSTRAINT `ts_user_role_ibfk_2` FOREIGN KEY (`ROLE_ID`) REFERENCES `ts_role` (`ROLE_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8 COMMENT='用户角色关联表';

-- 导出  表 sfopen2.ts_op_log 结构
CREATE TABLE IF NOT EXISTS `ts_op_log` (
  `LOG_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `USER_ID` bigint(11) DEFAULT NULL COMMENT '用户id',
  `USER_NAME` varchar(128) DEFAULT '' COMMENT '用户名',
  `USER_EXT_INFO` varchar(128) DEFAULT '' COMMENT '用户附加信息',
  `OP_MODULE` varchar(128) DEFAULT '' COMMENT '操作模块',
  `OP_TYPE` char(8) DEFAULT 'R' COMMENT '操作类型，CRT创建，DEL删除，UPD修改，GET查看，LOGIN 登录，LOGOUT 登出，DATAIN 导入，DATAOUT 导出，OT其他',
  `OP_PARAM` varchar(1024) DEFAULT '' COMMENT '操作参数',
  `OP_CONTENT` varchar(1024) DEFAULT '' COMMENT '操作内容',
  `OP_HOST_NAME` varchar(128) DEFAULT '' COMMENT '操作者主机名',
  `OP_IP` bigint(11) DEFAULT '0' COMMENT '操作者ip ，ip2long',
  `OP_TM` timestamp NULL DEFAULT NULL COMMENT '操作时间',
  `SERVICE_IP` bigint(11) DEFAULT '0' COMMENT '提供服务，机器ip ,ip2long',
  `SOURCE` char(4) DEFAULT 'W' COMMENT '操作来源，W-web，A-android，S-ios,X-weixin',
  `MEMO` varchar(1024) DEFAULT '' COMMENT '备注',
  `EXT1` varchar(128) DEFAULT '' COMMENT '扩展用',
  `EXT2` varchar(128) DEFAULT '' COMMENT '扩展用',
  `EXT3` varchar(128) DEFAULT '' COMMENT '扩展用',
  PRIMARY KEY (`LOG_ID`),
  KEY `idx_tm_operator_type` (`OP_TM`,`USER_NAME`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

