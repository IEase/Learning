module.exports = {
    userName: '',
    roleId: '',
    url: BACKGROUND,
	i18nFlag: true
}