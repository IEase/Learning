<template>
	<div class="iframe-view">
		<iframe width="100%" frameborder="0" height="100%" src="http://www.sf-express.com/cn/sc/"></iframe>
	</div>
</template>