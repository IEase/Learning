var utils = require('../build/utils')

module.exports = {
	'BACKGROUND': JSON.stringify('http://10.88.26.8:8080/'),
	'SfGATHERURL': JSON.stringify('http://218.17.248.243:40021/json_data')
}
