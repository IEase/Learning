module.exports = {
	'BACKGROUND': JSON.stringify('http://10.202.10.189:8080/'),
	'SfGATHERURL': JSON.stringify('https://inc-ubas-web.sf-express.com/json_data')
}
